// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdio.h>
#include <stdlib.h>
#include "fortix.h"

void PrintArray(const int8_t *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i += 8) {
        printf("%d %d %d %d %d %d %d %d\n",
               arr[i], arr[i + 1], arr[i + 2], arr[i + 3],
               arr[i + 4], arr[i + 5], arr[i + 6], arr[i + 7]);
    }
}

void FillArray(int *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i]  = i + 1;
    }
}

void FillArrayInt8(int8_t *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i]  = (int8_t)(i + 1);
    }
}

void FillArrayFloat(float *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i] = (float)(i + 1);
    }
}

int main(int argc, char *argv[]) {

    ftxDataLayout layout = FTX_NHWC;
    ftxDataType type = FTX_FP32;
    printf("Run test 0\n");

    int old_dims[] = {10};

    uint32_t arr_len = 10;
    float *arr_in = (float *)malloc(arr_len * sizeof(float));
    float *arr_weight = (float *)malloc(arr_len * sizeof(float));
    float *arr_out = (float *)malloc(arr_len * sizeof(float));

    FillArrayFloat(arr_in, arr_len);
    FillArrayFloat(arr_weight, arr_len);

    ftxTensor *in_tensor = ftxCreateTensor(old_dims, NULL, 1, type, layout, arr_in);
    ftxTensor *weight_tensor = ftxCreateTensor(old_dims, NULL, 1, type, layout, arr_weight);
    ftxTensor *out_tensor = ftxCreateTensor(old_dims, NULL, 1, type, layout, arr_out);
    printf("================Orig tensor================\n");
    ftxDumpTensor(in_tensor);

    ftxRMSNorm(in_tensor, weight_tensor, 1e-5f, out_tensor);
    printf("==============RMSNorm tensor==============\n");
    ftxDumpTensor(out_tensor);

    ftxSoftmax(in_tensor, out_tensor);
    printf("==============SoftMax tensor==============\n");
    ftxDumpTensor(out_tensor);

    printf("==============Silu tensor==============\n");
    ftxSwiglu(in_tensor,NULL, out_tensor);
    ftxDumpTensor(out_tensor);

    printf("==============Sin tensor==============\n");
    ftxSin(in_tensor, out_tensor);
    ftxDumpTensor(out_tensor);

    printf("==============Cos tensor==============\n");
    ftxCos(in_tensor, out_tensor);
    ftxDumpTensor(out_tensor);

    printf("==============RoPE tensor==============\n");
    ftxRope(in_tensor, 4, out_tensor);
    ftxDumpTensor(out_tensor);

    printf("Run test 0 DONE\n");

    ftxDestroyTensor(in_tensor);
    ftxDestroyTensor(weight_tensor);
    ftxDestroyTensor(out_tensor);

    free(arr_in);
    free(arr_weight);
    free(arr_out);
    return 0;
}
