// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <vector>
#include <memory>

#include "fortix.h"

enum Pattern {
    RAND,
    SEQUENTIAL,
    FIXED
};

void PrintArray(const float *arr, uint32_t m, uint32_t n) {
    for (uint32_t i = 0; i < m; ++i) {
        for (uint32_t j = 0; j < n; ++j) {
            std::cout << arr[i * n + j] << " ";
        }
        std::cout << "\n";
    }
}

void FillArray(int *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i]  = i + 1;
    }
}

void FillArrayInt8(int8_t *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i]  = static_cast<int8_t>(rand() % 16 - 8);
    }
}

void FillArrayFloat(float *arr, uint32_t arr_len, Pattern pattern) {
    for (uint32_t i = 0; i < arr_len; i++) {
        switch (pattern) {
        case RAND:
            arr[i] = static_cast<float>((float)rand() / RAND_MAX * 16.0f - 8.0f);
            break;
        case FIXED:
            arr[i] = 1.0f;
            break;
        case SEQUENTIAL:
            arr[i] = static_cast<float>(i);
            break;
        }

    }
}

struct timespec diff(struct timespec start, struct timespec end) {
    struct timespec temp;
    if ((end.tv_nsec-start.tv_nsec)<0) {
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    } else {
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

int main(int argc, char *argv[]) {
    ftxStatus status;
    ftxDataLayout layout = FTX_NHWC;
    struct timespec start, end, temp;
    double time_elapsed;
    std::cout << "Run test 0\n";

    int m = 256, k = 256, n = 256;
    int x = 1024, y = 1024, z = 1024;

    std::vector<int> a_dims = {m, k};
    std::vector<int> b_dims = {k, n};
    std::vector<int> bt_dims = {n, k};
    std::vector<int> c_dims = {m, n};
    std::vector<int> d_dims = {x, y};
    std::vector<int> e_dims = {y, z};
    std::vector<int> f_dims = {x, z};

    uint32_t len_a = m * k, len_b = k * n, len_c = m * n;
    uint32_t len_d = x * y, len_e = y * z, len_f = x * y;

    float *arr_a = (float *)ftxMalloc(len_a * sizeof(float));
    float *arr_b = (float *)ftxMalloc(len_b * sizeof(float));
    float *arr_c = (float *)ftxMalloc(len_c * sizeof(float));
    float *arr_d = (float *)ftxMalloc(len_d * sizeof(float));
    float *arr_e = (float *)ftxMalloc(len_e * sizeof(float));
    float *arr_f = (float *)ftxMalloc(len_f * sizeof(float));

    FillArrayFloat(arr_a, len_a, RAND);
    FillArrayFloat(arr_b, len_b, RAND);
    FillArrayFloat(arr_c, len_c, RAND);
    FillArrayFloat(arr_d, len_d, RAND);

    size_t free_size, total;
    ftxGetMemInfo(&free_size, &total);
    printf("free: %lu total: %lu\n\n", (int64_t)free_size, (int64_t)total);

    ftxTensor *tensor_a = ftxCreateTensor(a_dims.data(), nullptr, 2, FTX_FP32, layout, arr_a);
    ftxTensor *tensor_b = ftxCreateTensor(b_dims.data(), nullptr, 2, FTX_FP32, layout, arr_b);
    ftxTensor *tensor_c = ftxCreateTensor(c_dims.data(), nullptr, 2, FTX_FP32, layout, arr_c);
    ftxTensor *tensor_d = ftxCreateTensor(d_dims.data(), nullptr, 2, FTX_FP32, layout, arr_d);
    ftxTensor *tensor_e = ftxCreateTensor(e_dims.data(), nullptr, 2, FTX_FP32, layout, arr_e);
    ftxTensor *tensor_f = ftxCreateTensor(f_dims.data(), nullptr, 2, FTX_FP32, layout, arr_f);

    ftxContext *ctx = ftxCreateContext();
    ftxSetGEMMSize(ctx, 256);

    clock_gettime(CLOCK_MONOTONIC, &start);
    status = ftxMatmul(ctx, tensor_a, tensor_b, false, nullptr, 1.0f, tensor_c);
    clock_gettime(CLOCK_MONOTONIC, &end);
    printf("Matmul tensor_a x tensor_b error status: %x\n", status);
    temp = diff(start, end);
    time_elapsed = temp.tv_sec + (double) temp.tv_nsec / 1000000000.0;
    printf("Elapsed time of ftxMatmul = %.9lf(s)\n\n",time_elapsed);

    ftxSetGEMMSize(ctx, 1024);
    clock_gettime(CLOCK_MONOTONIC, &start);
    status = ftxMatmul(ctx, tensor_d, tensor_e, false, nullptr, 1.0f, tensor_f);
    clock_gettime(CLOCK_MONOTONIC, &end);
    printf("Matmul tensor_d x tensor_e error status: %x\n", status);
    temp = diff(start, end);
    time_elapsed = temp.tv_sec + (double) temp.tv_nsec / 1000000000.0;
    printf("Elapsed time of ftxMatmul = %.9lf(s)\n\n",time_elapsed);
    ftxShowStats(ctx);

    ftxDestroyTensor(tensor_a);
    ftxDestroyTensor(tensor_b);
    ftxDestroyTensor(tensor_c);
    ftxDestroyTensor(tensor_d);
    ftxDestroyTensor(tensor_e);
    ftxDestroyTensor(tensor_f);

    ftxFree(arr_a);
    ftxFree(arr_b);
    ftxFree(arr_c);
    ftxFree(arr_d);
    ftxFree(arr_e);
    ftxFree(arr_f);

    ftxDestroyContext(ctx);

    return 0;
}
