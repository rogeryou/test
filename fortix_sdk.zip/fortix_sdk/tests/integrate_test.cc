#include<stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <cassert>
#include <cstring>
#include <memory>
#include <mutex>
#include <set>
#include <thread>
#include <vector>
#include <iostream>
// #include <dmlc/thread_local.h>

// #include "../../src/runtime/workspace_pool.h"
#include "runtime/runtime.h"
#include "fortix.h"
// #include "vta/device_api.h"

// using namespace dcim;

void FillArray(int *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        arr[i]  = std::rand() % 32 - 16;
    }
}

void PrintArray(const int8_t *arr, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i += 8) {
        std::cout << static_cast<int32_t>(arr[i]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 1]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 2]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 3]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 4]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 5]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 6]) << " ";
        std::cout << static_cast<int32_t>(arr[i + 7]) << "\n";
    }
}

// static int UopSetUp(void* signiture){
//     ftxUopLoopBegin(64,1,1,0);
//     ftxUopPush(1,0,0,64,0,2,0,0);
//     ftxUopLoopEnd();
//     return 0;
// }

void vadd(const int* a, const int* b, int8_t* out, uint32_t arr_len) {
    for (uint32_t i = 0; i < arr_len; i++) {
        out[i] = static_cast<int8_t>(a[i] + b[i]);
    }
}

int UopALUSetL1(UopSet sign){
    ftxUopLoopBegin(sign.extent[0],sign.factor[0][0],sign.factor[0][1],sign.factor[0][2]);
    ftxUopPush(sign.mode,sign.reset_out,sign.index[0],sign.index[1],sign.index[2],sign.opcode,sign.use_imm,sign.imm_val);
    ftxUopLoopEnd();
    return 0;
}

int main(){
    uint32_t arr_len = 1024;
    int orig_dims[] = {1, 1024};
    int new_dims[] = {1, 64, 1, 16};
    int *data1 = new int[arr_len];
    int *data2 = new int[arr_len];
    int8_t *out = new int8_t[arr_len];

    std::cout << "Integration test\n";
    // Input data
    FillArray(data1, arr_len);
    ftxTensor *tensor1 = ftxCreateTensor(orig_dims, nullptr, 2, FTX_INT32, FTX_2D, data1);
    FillArray(data2, arr_len);
    ftxTensor *tensor2 = ftxCreateTensor(orig_dims, nullptr, 2, FTX_INT32, FTX_2D, data2);

    // Reshape to 4D tensor
    ftxReshape(tensor1, new_dims, 4, nullptr);
    ftxReshape(tensor2, new_dims, 4, nullptr);

    // Output data
    ftxTensor *tensor3 = ftxCreateTensor(new_dims, nullptr, 4, FTX_INT8, FTX_4D, out);

    size_t buf_size1, buf_size2, buf_size3;
    ftxGetBufferSize(tensor1, &buf_size1);
    ftxGetBufferSize(tensor2, &buf_size2);
    ftxGetBufferSize(tensor3, &buf_size3);

    auto tensor1_to = ftxBufferAlloc(buf_size1);
    auto tensor2_to = ftxBufferAlloc(buf_size1);
    auto tensor3_to = ftxBufferAlloc(buf_size3);

    ftxBufferCopy(data1, 0, tensor1_to, 0, buf_size1, 1);
    ftxBufferCopy(data2, 0, tensor2_to, 0, buf_size2, 1);

    //Prepare load data insn
    ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor1_to,0,64,1,64,0,0,0,0,0,3);
    ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor2_to,0,64,1,64,0,0,0,0,64,3);

    // dependent flag
    ftxDepPush(ftxTLSCommandHandle(),1,2);
    ftxDepPop(ftxTLSCommandHandle(),1,2);

    // Prepare ALU insn
    void* ptr = nullptr;
    ftxCreateUopKernelMap(ptr);
    UopSet ALUAdd = {1,0,2,0,0,
        .index = {0,64,0},
        .extent = {64},
        .factor = {{1,1,0}}
    };
    ftxPushALUOp(static_cast<void**>(&ptr), UopALUSetL1, ALUAdd, 0, 0);

    // dependent flag
    ftxDepPush(ftxTLSCommandHandle(),2,3);
    ftxDepPop(ftxTLSCommandHandle(),2,3);

    // Prepare Store output insn
    ftxStoreBuffer2D(ftxTLSCommandHandle(),0,4,tensor3_to,0,64,1,64);

    // sunchronize
    ftxSynchronize(ftxTLSCommandHandle(),2147483648);
    // *Still don't know what the wait cycle means here

    // copy data to host
    ftxBufferCopy(tensor3_to, 0, out, 0, buf_size3, 2);

    // Reshape back to original dimension
    ftxReshape(tensor3, orig_dims, 2, nullptr);
    ftxDumpTensor(tensor3);

    ftxBufferFree(tensor3_to);
    ftxBufferFree(tensor2_to);
    ftxBufferFree(tensor1_to);

    int8_t* ref = new int8_t[arr_len];
    vadd(data1, data2, ref, arr_len);

    if (memcmp(ref, out, arr_len)) {
        std::cout << "Comparision failed!\n";
        PrintArray(ref, arr_len);
    } else {
        std::cout << "Comparision success!\n";
    }

    ftxDestroyTensor(tensor1);
    ftxDestroyTensor(tensor2);
    ftxDestroyTensor(tensor3);

    delete data1;
    delete data2;
    delete ref;
    delete out;

    return 0;
}
