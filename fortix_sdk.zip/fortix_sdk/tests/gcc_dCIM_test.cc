#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <cassert>
#include <cstring>
#include <memory>
#include <mutex>
#include <set>
#include <thread>
#include <vector>
#include <iostream>
#include <math.h>
#include <time.h>
// #include <dmlc/thread_local.h>

// #include "../../src/runtime/workspace_pool.h"
#include "runtime/runtime.h"
#include "dCIM/hw_spec_const.h"
#include "cpu/quant.h"

// forix
#include "fortix.h"
#include "fortix_private.h"

void print_device(){
    #ifdef USE_OPENBLAS
        std::cout<<"use openblas"<<std::endl;
    #endif
    #ifdef USE_MKL
        std::cout<<"use MKL"<<std::endl;
    #endif
    #ifdef USE_CPU
        std::cout<<"use CPU"<<std::endl;
    #endif
}

struct Tensor{
    int32_t* data_int32;
    int8_t* data_int8;
    size_t shape[4];
    size_t size_tensor;
    size_t elem_bits;

    Tensor(size_t s0, size_t s1,size_t s2,size_t s3, size_t bits){
        shape[0]=s0;
        shape[1]=s1;
        shape[2]=s2;
        shape[3]=s3;

        size_tensor = s0*s1*s2*s3;
        elem_bits = bits;
        data_int32 = new int32_t[size_tensor];
        data_int8 = new int8_t[size_tensor];

    }
    ~Tensor(){
        delete[] data_int32;
        delete[] data_int8;
    }
};
void BuildTensorData(Tensor* tensor, std::string datatype){
    if (datatype=="int8"){
        for (long unsigned int i=0;i<tensor->size_tensor;i++){
            tensor->data_int8[i] = static_cast<int8_t>(rand()%256-128);
        }
    }
    else if (datatype=="int4"){
        for (long unsigned int i=0;i<tensor->size_tensor;i++){
            tensor->data_int8[i] = static_cast<int8_t>(rand()%32-16);
        }
    }
    else if (datatype=="int32"){
        for (long unsigned int i=0;i<tensor->size_tensor;i++){
            tensor->data_int32[i] = static_cast<int32_t>(rand()%(2^32)-(2^31));
        }
    }
    else printf("random build tensor only supports int8 and int4");
}

void* PrepareBuffers(Tensor* tensor, std::string datatype,const int imm=0, bool is_random=false){
    // prepare tensor for add code
    void* tensor_to = nullptr;
    if (datatype=="int32"){
        if (is_random)
            BuildTensorData(tensor,"int32");
        else
            memset(tensor->data_int32,imm,(tensor->size_tensor)*sizeof(int32_t));
        tensor_to = ftxBufferAlloc(tensor->size_tensor*sizeof(int32_t));
        ftxBufferCopy(static_cast<void*>(tensor->data_int32), 0, tensor_to, 0, tensor->size_tensor*sizeof(int32_t),1);
    }
    else if (datatype=="int8"){
        if (is_random)
            BuildTensorData(tensor,"int8");
        else
            memset(tensor->data_int8,imm,(tensor->size_tensor)*sizeof(int8_t));

        tensor_to = ftxBufferAlloc(tensor->size_tensor*sizeof(int8_t));
        ftxBufferCopy(static_cast<void*>(tensor->data_int8), 0, tensor_to, 0, tensor->size_tensor*sizeof(int8_t),1);
    }
    else {
        throw std::invalid_argument("data type is not support");
    }

    return tensor_to;
}

// int UopAddSetUp(void* signiture){
//     ftxUopLoopBegin(64,1,1,0);
//     ftxUopPush(1,0,0,64,0,2,0,0);
//     ftxUopLoopEnd();
//     return 0;
// }

int UopGEMMSetUp(void* signiture){
    static int a=0;
    ftxUopLoopBegin(32,2,a,0);
    ftxUopLoopBegin(2,1,0,a);
    ftxUopPush(0,1-a,0,0,0,0,0,0);
    ftxUopLoopEnd();
    ftxUopLoopEnd();
    a++;
    return 0;
}

// Push value: (ALU/GEMM, , , , ,alu mode,use_imm,imm_value)
// mode=0~4: min, max, add, shr, mul
// other four value is reset_out and uop index since iterating for one value after gemm so index=0


int UopGEMMSet(UopSet sign){
    ftxUopPush(sign.mode,sign.reset_out,sign.index[0],sign.index[1],sign.index[2],sign.opcode,sign.use_imm,sign.imm_val);
    return 0;
}

int UopALUSet(UopSet sign){
    ftxUopPush(sign.mode,sign.reset_out,sign.index[0],sign.index[1],sign.index[2],sign.opcode,sign.use_imm,sign.imm_val);
    return 0;
}

int UopALUSetL1(UopSet sign){
    ftxUopLoopBegin(sign.extent[0],sign.factor[0][0],sign.factor[0][1],sign.factor[0][2]);
    ftxUopPush(sign.mode,sign.reset_out,sign.index[0],sign.index[1],sign.index[2],sign.opcode,sign.use_imm,sign.imm_val);
    ftxUopLoopEnd();
    return 0;
}


int UopGEMMSetL2(UopSet sign){
    ftxUopLoopBegin(sign.extent[0],sign.factor[0][0],sign.factor[0][1],sign.factor[0][2]);
    ftxUopLoopBegin(sign.extent[1],sign.factor[1][0],sign.factor[1][1],sign.factor[1][2]);
    ftxUopPush(sign.mode,sign.reset_out,sign.index[0],sign.index[1],sign.index[2],sign.opcode,sign.use_imm,sign.imm_val);
    ftxUopLoopEnd();
    ftxUopLoopEnd();
    return 0;
}

void dCIMAddOperator(uint32_t tensor_size){
    // input data
    assert(tensor_size%16==0);
    Tensor tensor1(1,tensor_size/DCIM_BLOCK_OUT,1,DCIM_BLOCK_OUT,sizeof(int32_t)*8);
    Tensor tensor2(1,tensor_size/DCIM_BLOCK_OUT,1,DCIM_BLOCK_OUT,sizeof(int32_t)*8);
    // output data
    Tensor tensor3(1,tensor_size/DCIM_BLOCK_OUT,1,DCIM_BLOCK_OUT,sizeof(int8_t)*8);

    auto tensor1_to = PrepareBuffers(&tensor1,"int32",0,true);
    auto tensor2_to = PrepareBuffers(&tensor2,"int32",0,true);
    auto tensor3_to = PrepareBuffers(&tensor3,"int8",0);
    //Prepare load data insn
    ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor1_to,0,tensor_size/DCIM_BLOCK_OUT,1,tensor_size/DCIM_BLOCK_OUT,0,0,0,0,0,3);
    ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor2_to,0,tensor_size/DCIM_BLOCK_OUT,1,tensor_size/DCIM_BLOCK_OUT,0,0,0,0,tensor_size/DCIM_BLOCK_OUT,3);

    // Prepare ALU insn
    void* ptr = nullptr;
    ftxCreateUopKernelMap(ptr);

    UopSet ALUAdd = {1,0,2,0,0,
        .index = {0,tensor_size/DCIM_BLOCK_OUT,0},
        .extent = {tensor_size/DCIM_BLOCK_OUT},
        .factor = {{1,1,0}}
    };
    ftxPushALUOp(static_cast<void**>(&ptr), UopALUSetL1, ALUAdd, 0, 0);

    // dependent flag
    ftxDepPush(ftxTLSCommandHandle(),2,3);
    ftxDepPop(ftxTLSCommandHandle(),2,3);

    // Prepare Store output insn
    ftxStoreBuffer2D(ftxTLSCommandHandle(),0,4,tensor3_to,0,tensor_size/DCIM_BLOCK_OUT,1,tensor_size/DCIM_BLOCK_OUT);

    // sunchronize
    ftxSynchronize(ftxTLSCommandHandle(),2147483648);
    // *Still don't know what the wait cycle means here

    // copy data to host
    ftxBufferCopy(tensor3_to,0, static_cast<void*>(tensor3.data_int8), 0, tensor3.size_tensor*sizeof(int8_t),2);
    std::cout<<"result= "<<sizeof(tensor3.data_int8)<<std::endl;
    for(int i=0;i<static_cast<int>(tensor3.size_tensor);i++){
        printf(" %d",static_cast<int>(tensor3.data_int8[i]));
    }
    printf("\n");
    ftxBufferFree(tensor3_to);
    ftxBufferFree(tensor2_to);
    ftxBufferFree(tensor1_to);
}

void dCIMGemmOperator(){
    // input data
    Tensor tensor1(32,2,1,16,sizeof(int8_t)*8);
    Tensor tensor2(2,2,16,16,sizeof(int8_t)*8);
    // output data
    Tensor tensor3(32,2,1,16,sizeof(int8_t)*8);

    auto tensor1_to = PrepareBuffers(&tensor1,"int8",0,true);
    auto tensor2_to = PrepareBuffers(&tensor2,"int8",0,true);
    auto tensor3_to = PrepareBuffers(&tensor3,"int8",0,false);
    int ko=2;

    void* ptr = nullptr;
    ftxCreateUopKernelMap(ptr);

    UopSet GEMM = {0,0,0,0,0,
        .index = {0,0,0},
        .extent = {32,2},
        .factor = {{2,1,0},{1,0,1}}
    };

    for (int i=0;i<ko;i++){
        ftxDepPush(ftxTLSCommandHandle(),2,1);
        ftxDepPop(ftxTLSCommandHandle(),2,1);
        ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor1_to,i,1,32,2,0,0,0,0,0,2);
        ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor2_to,i,1,2,2,0,0,0,0,0,1);
        ftxDepPush(ftxTLSCommandHandle(),1,2);

        ftxDepPop(ftxTLSCommandHandle(),1,2);
        // Prepare GEMM insn
        ftxPushGEMMOp(static_cast<void**>(&ptr), UopGEMMSetL2, GEMM, 0, 0);
        // ftxDepPush(ftxTLSCommandHandle(),2,1);
        // ftxDepPop(ftxTLSCommandHandle(),2,1);

    }

    // dependent flag
    ftxDepPush(ftxTLSCommandHandle(),2,3);
    ftxDepPop(ftxTLSCommandHandle(),2,3);

    // Prepare Store output insn
    ftxStoreBuffer2D(ftxTLSCommandHandle(),0,4,tensor3_to,0,64,1,64);

    // sunchronize
    ftxSynchronize(ftxTLSCommandHandle(),2147483648);
    // *Still don't know what the wait cycle means here

    // copy data to host
    ftxBufferCopy(tensor3_to,0, static_cast<void*>(tensor3.data_int8), 0, tensor3.size_tensor*sizeof(int8_t),2);
    std::cout<<"result= "<<sizeof(tensor3.data_int32)<<std::endl;
    for(int i=0;i<static_cast<int>(tensor3.size_tensor);i++){
        printf(" %d",static_cast<int>(tensor3.data_int8[i]));
    }
    printf("\n");
    ftxBufferFree(tensor3_to);
    ftxBufferFree(tensor2_to);
    ftxBufferFree(tensor1_to);
}

void dCIMMatmulOperator(const int batch_size=32, const int inchannel=32,const int outchannel=32){
    // input data (32*32)
    // check data size since without padding
    assert(batch_size%DCIM_BATCH == 0);
    assert(inchannel%DCIM_BLOCK_IN == 0);
    assert(outchannel%DCIM_BLOCK_OUT == 0);

    Tensor tensor1(batch_size/DCIM_BATCH,inchannel/DCIM_BLOCK_IN,DCIM_BATCH,DCIM_BLOCK_IN,sizeof(int8_t)*8);
    Tensor tensor2(inchannel/DCIM_BLOCK_IN,outchannel/DCIM_BLOCK_OUT,DCIM_BLOCK_IN,DCIM_BLOCK_OUT,sizeof(int8_t)*8);
    // output data
    Tensor tensor3(batch_size/DCIM_BATCH,outchannel/DCIM_BLOCK_OUT,DCIM_BATCH,DCIM_BLOCK_OUT,sizeof(int8_t)*8);

    auto tensor1_to = PrepareBuffers(&tensor1,"int8",0,true);
    auto tensor2_to = PrepareBuffers(&tensor2,"int8",0,true);
    auto tensor3_to = PrepareBuffers(&tensor3,"int8",0);

    // set alu uop func
    UopSet AluShr = {1,0,3,1,DCIM_WGT_WIDTH};
    UopSet AluMin = {1,0,0,1,(1<<(DCIM_INP_WIDTH-1))-1};
    UopSet AluMax = {1,0,1,1,-(1<<(DCIM_INP_WIDTH-1))};

    UopSet GEMM = {0,0,0,0,0};

    void* ptr3_1 = nullptr;
    ftxCreateUopKernelMap(ptr3_1);
    void* ptr3_2 = nullptr;
    ftxCreateUopKernelMap(ptr3_2);
    void* ptr3_3 = nullptr;
    ftxCreateUopKernelMap(ptr3_3);
    void* ptr2 = nullptr;
    ftxCreateUopKernelMap(ptr2);

    // (ex: dCIM batch=1, blockout=blockin=16, do a 32*32 gemm)
    // i0_0: batch size, i0_1: outer loop(ex: vatch size=32, outer loop=32/block_out=2)
    for(int i=0;i<(batch_size/DCIM_BATCH);i++){
        for (int j=0;j<(outchannel/DCIM_BLOCK_OUT);j++){
            for(int k=0;k<(inchannel/DCIM_BLOCK_IN);k++){
                // dependent flag
                ftxDepPush(ftxTLSCommandHandle(),2,1);
                ftxDepPop(ftxTLSCommandHandle(),2,1);
                // Load buffer: input buffer=2, wgt buffer =1
                ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor1_to,i*(inchannel/DCIM_BLOCK_IN)+k,1,1,1,0,0,0,0,0,2);
                ftxLoadBuffer2D(ftxTLSCommandHandle(),tensor2_to,j*(inchannel/DCIM_BLOCK_IN)+k,1,1,1,0,0,0,0,0,1);
                // dependent flag
                ftxDepPush(ftxTLSCommandHandle(),1,2);
                ftxDepPop(ftxTLSCommandHandle(),1,2);
                // Prepare GEMM insn
                ftxPushGEMMOp(static_cast<void**>(&ptr2), UopGEMMSet, GEMM, 0, 0);

            }
            // Prepare ALU insn
            ftxPushALUOp(static_cast<void**>(&ptr3_1), UopALUSet, AluShr, 0, 0);
            ftxPushALUOp(static_cast<void**>(&ptr3_2), UopALUSet, AluMin, 0, 0);
            ftxPushALUOp(static_cast<void**>(&ptr3_3), UopALUSet, AluMax, 0, 0);
            // dependent flag
            ftxDepPush(ftxTLSCommandHandle(),2,3);
            ftxDepPop(ftxTLSCommandHandle(),2,3);
            // Prepare Store output insn
            ftxStoreBuffer2D(ftxTLSCommandHandle(),0,4,tensor3_to,i*(outchannel/DCIM_BLOCK_OUT)+j,1,1,1);
            // dependent flag
            ftxDepPush(ftxTLSCommandHandle(),3,2);
            ftxDepPop(ftxTLSCommandHandle(),3,2);
        }
    }
    // synchronize
    ftxSynchronize(ftxTLSCommandHandle(),2147483648);
    // *Still don't know what the wait cycle means here

    // copy data to host
    ftxBufferCopy(tensor3_to,0, static_cast<void*>(tensor3.data_int8), 0, tensor3.size_tensor*sizeof(int8_t),2);

    // Print the answer of dense
    // just emulate print the output data, actually the output data shape is (batch_size,outchannel/block_out,batch,blockout)
    // We need reshape and transpose to transform the data to right order (batch, outchannel)
    for(int i=0;i<batch_size;i++){
        for(int j=0;j<outchannel;j++)
            printf(" %4d",static_cast<int>(tensor3.data_int8[i*outchannel+j]));
        printf("\n");
    }
    printf("the batch size is:%d, the outchannel size is:%d\n",batch_size,outchannel);

    // Release the buffer in device
    ftxBufferFree(tensor3_to);
    ftxBufferFree(tensor2_to);
    ftxBufferFree(tensor1_to);
    ftxDeleteUopKernelMap(ptr2);
    ftxDeleteUopKernelMap(ptr3_1);
    ftxDeleteUopKernelMap(ptr3_2);
    ftxDeleteUopKernelMap(ptr3_3);
}

struct timespec diff(struct timespec start, struct timespec end) {
    struct timespec temp;
    if ((end.tv_nsec-start.tv_nsec)<0) {
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    } else {
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}
void generate_data(float *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (float)rand() / (float)(RAND_MAX / 10);
        // data[i] = (1+i)*100;
    }
}
void generate_data_const(float *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        data[i] = 0.001f;
        // data[i] = 1+i;
    }
}

void generate_data_int8(int8_t *data, size_t len) {
    for (size_t i = 0; i < len; i++) {
        data[i] = (int8_t)rand() ;
        // data[i] = 1+i;
    }
}
// print_data(c, size, size);
// Function to convert a float to a 16-bit half-precision
float16 float_to_fp16(float f) {
    uint32_t bits = *((uint32_t*)&f); // Get the 32-bit representation of the float
    uint32_t sign = (bits >> 31) & 0x1;
    uint32_t exponent = (bits >> 23) & 0xFF;
    uint32_t mantissa = bits & 0x7FFFFF;

    // Handle exponent overflow and underflow
    if (exponent == 0xFF) {
        exponent = 0x1F;
    } else if (exponent == 0) {
        exponent = 0;
    } else {
        exponent -= 112; // Convert to 5-bit exponent
    }

    // Scale the mantissa to fit into 10 bits
    mantissa >>= 13;

    // Pack the float16_t representation
    return (sign << 15) | (exponent << 10) | mantissa;
}

void print_fp16_array(float16 *array, int size) {
    for (int i = 0; i < size; i++) {
        printf("Element %d (fp16): 0x%04X\n", i, array[i]);
    }
}

void test_for_ops(){
    // dCIMAddOperator(256);
    // dCIMGemmOperator();
    // dCIMMatmulOperator(256,256,256);

    int test_cnt = 20;
    struct timespec start, end, temp;
    double time_used;

    // activation sin cos
    std::vector<int> inp_dims = {20};
    int a = ComputeSize(inp_dims);
    int8_t *arr0 = new int8_t[a];
    generate_data_int8(arr0, a);
    ftxTensor *in_tensor = ftxCreateTensor(inp_dims.data(), nullptr, inp_dims.size(), FTX_INT8, FTX_1D, arr0);

    std::vector<int> inp_dims1 = {1};
    size_t b = ComputeSize(inp_dims1);
    int8_t *arr1 = new int8_t[b];
    generate_data_int8(arr1, b);
    ftxTensor *in_tensor1 = ftxCreateTensor(inp_dims1.data(), nullptr, inp_dims1.size(), FTX_INT8, FTX_1D, arr1);


    vector<int> out_dims = BroadcastOutShape(in_tensor->Shape(), in_tensor1->Shape());
    size_t o = ComputeSize(out_dims);
    float *arr_out = new float[o];
    ftxTensor *out_tensor = ftxCreateTensor(out_dims.data(), nullptr, out_dims.size(), FTX_FP32, FTX_2D, arr_out);

    // ftxTensor *out_tensor = ftxBroadcastOutTensor(in_tensor, in_tensor1);

    // // embedding
    // int k = 5;
    // int n = 10;
    // std::vector<int> inp_dims = {n,k};
    // int8_t *arr0 = new int8_t[n*k];
    // generate_data_int8(arr0,n*k);
    // ftxTensor *in_tensor = ftxCreateTensor(inp_dims.data(), 2, FTX_INT8, FTX_2D, arr0);

    // int index_num=2;
    // int indice_tensor[index_num] = {2,3};
    // std::vector<int> indice_dims = {index_num};
    // // ftxTensor *indice_tensor = ftxCreateTensor(indice_dims.data(), 1, FTX_INT32, FTX_1D, indice);

    // int8_t *arr_out = new int8_t[indice_dims[0]*k];
    // std::vector<int> out_dims = {indice_dims[0],k};
    // ftxTensor *out_tensor = ftxCreateTensor(out_dims.data(), 2, FTX_INT8, FTX_2D, arr_out);

    // // RMSnorm
    // std::vector<int> inp_dims = {n,n};
    // float *arr0 = new float[n*n];
    // generate_data(arr0,n*n);
    // ftxTensor *in_tensor = ftxCreateTensor(inp_dims.data(), 2, FTX_FP32, FTX_2D, arr0);

    // std::vector<int> gamma_dims = {n,n};
    // float *arr_gamma = new float[n*n];
    // generate_data(arr0,n*n);
    // ftxTensor *gamma_tensor = ftxCreateTensor(gamma_dims.data(), 2, FTX_FP32, FTX_2D, arr_gamma);

    // float *arr_out = new float[n*n];
    // std::vector<int> out_dims = {n,n};
    // ftxTensor *out_tensor = ftxCreateTensor(out_dims.data(), 2, FTX_FP32, FTX_2D, arr_out);

    //  CPY test
    // Define float16_t as a 16-bit unsigned integer



    // int size = 20; // Size of the fp16 array
    // float16 fp16_array[size];

    // // Initialize the array with some float values
    // float values[] = {1.0f, 3.14f, 2.718f, -1.0f, 0.5f, 1.0f, 3.14f, 2.718f, -1.0f, 0.5f, 1.0f, 3.14f, 2.718f, -1.0f, 0.5f, 1.0f, 3.14f, 2.718f, -1.0f, 0.5f};

    // for (int i = 0; i < size; i++) {
    //     fp16_array[i] = float_to_fp16(values[i]);
    // }

    // Initialize the array with some float values
    // int8_t int8_array[size] = {2,120,1,-125,-23,64,26,-12,-64,0,-77,24,-64,16,26,-12,-64,12,-77,24};

    // std::vector<int> dims = {size};

    // // ftxTensor *in_tensor = ftxCreateTensor(dims.data(), 1, FTX_FP16, FTX_1D, fp16_array);
    // ftxTensor *in_tensor = ftxCreateTensor(dims.data(), 1, FTX_INT8, FTX_1D, int8_array);

    // float *arr_out = new float[size];
    // ftxTensor *out_tensor = ftxCreateTensor(dims.data(), 1, FTX_FP32, FTX_1D, arr_out);



    // Print the resulting fp16 values in hexadecimal
    // print_fp16_array(fp16_array, size);


    clock_gettime(CLOCK_MONOTONIC, &start);
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxSilu(in_tensor, NULL, out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxSoftmax(in_tensor,out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxEmbedding(in_tensor,indice_tensor,2,out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxRMSNorm(in_tensor,gamma_tensor,1e-5f,out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxSin(in_tensor,out_tensor)==FTX_OK);
    // }

    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxAdd(in_tensor, in_tensor1, out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxSub(in_tensor, in_tensor1, out_tensor)==FTX_OK);
    // }
    for (int i = 0; i < test_cnt; i++) {
        assert(ftxMul(in_tensor, in_tensor1, out_tensor)==FTX_OK);
    }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxDiv(in_tensor, in_tensor1, out_tensor)==FTX_OK);
    // }
    // for (int i = 0; i < test_cnt; i++) {
    //     assert(ftxCpy(in_tensor, out_tensor)==FTX_OK);
    // }



    clock_gettime(CLOCK_MONOTONIC, &end);

    ftxDumpTensor(in_tensor);
    ftxDumpTensor(in_tensor1);
    ftxDumpTensor(out_tensor);

    temp = diff(start, end);
    time_used = temp.tv_sec + (double) temp.tv_nsec / 1000000000.0;

    print_device();
    printf("Time of %d test = %f(s)\n", test_cnt, time_used / test_cnt);

    // printf("sin result:\n");
    // for (int i=0;i<n;i++){
    //     printf("%.6f ",arr_out[i]);
    // }
    // printf("\n");
    // printf("input result:\n");
    // for (int i=0;i<n;i++){
    //     for (int j=0;j<k;j++){
    //         printf("%.6f ",arr0[i*k+j]);
    //     }
    //     printf("\n");
    // }
    // printf("embedding result:\n");
    // for (int i=0;i<indice_dims[0];i++){
    //     for (int j=0;j<k;j++){
    //         printf("%.6f ",arr_out[i*k+j]);
    //     }
    //     printf("\n");
    // }
}

int main(){
    // quant

    int block_size = 32;

    int M = 1, K = 288, N = 2;

    std::vector<int> q8_dims = {N, K};
    size_t b = ComputeSize(q8_dims);
    int8_t *arr1 = new int8_t[b];
    generate_data_int8(arr1, b);
    ftxTensor *q8_tensor = ftxCreateTensor(q8_dims.data(), nullptr, q8_dims.size(), FTX_INT8, FTX_2D, arr1);

    int K_s = (K % block_size) ? (K / block_size + 1) : (K / block_size); 
    // printf("the inp scale dim: %d\n",K_s);
    std::vector<int> wgt_s_dims = {N, K_s};
    size_t bs = ComputeSize(wgt_s_dims);
    float *arr1s = new float[bs];
    generate_data_const(arr1s, bs);
    ftxTensor *s_tensor = ftxCreateTensor(wgt_s_dims.data(), nullptr, wgt_s_dims.size(), FTX_FP32, FTX_2D, arr1s);
    
    std::vector<int> inp_dims = {M, K};
    size_t a = ComputeSize(inp_dims);
    float *arr0 = new float[a];
    generate_data(arr0, a);
    ftxTensor *inp_tensor = ftxCreateTensor(inp_dims.data(), nullptr, inp_dims.size(), FTX_FP32, FTX_2D, arr0);

    
    vector<int> out_dims = {M, N};
    size_t o = ComputeSize(out_dims);
    float *arr_out = new float[o];
    ftxTensor *out_tensor = ftxCreateTensor(out_dims.data(), nullptr, out_dims.size(), FTX_FP32, FTX_2D, arr_out);


    int test_cnt = 1;
    struct timespec start, end, temp;
    double time_used;

    clock_gettime(CLOCK_MONOTONIC, &start);
    
    for(int i = 0; i < test_cnt; i++) {
        assert(ftxQuantMatmul(inp_tensor, NULL, q8_tensor, s_tensor, true,
                        block_size, out_tensor) == FTX_OK);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);

    temp = diff(start, end);
    time_used = temp.tv_sec + (double) temp.tv_nsec / 1000000000.0;

    // print_device();
    printf("Time of %d test = %f(s)\n", test_cnt, time_used / test_cnt);

    // ftxDumpTensor(inp_tensor);

    // ftxDumpTensor(q8_tensor);
    // ftxDumpTensor(s_tensor);
    
    
    ftxDumpTensor(out_tensor);

    return 0;
}