import numpy as np
# np.show_config()

import time


A = np.random.rand(10, 1, 4096)

B = np.random.rand(4096, 4096)

# A = np.arange(1, 4*2*5+1).reshape((4, 2, 5))
# B = np.arange(1, 1*2*5+1).reshape((2, 5))

# print(A.strides)

# print(A.shape)
# print(A)
# print(B.shape)
# print(B)

start_time = time.time()

C = np.subtract(B, A)
# time.sleep(2)
end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed Time: {elapsed_time} seconds")

# print(C.shape)
# print(C)