// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <cstdlib>
#include <cstring>

#include "fortix.h"
#include "fortix_private.h"

ftxTensor::ftxTensor(const int *dims, const int *strides, size_t ndim, ftxDataType type,
        ftxDataLayout layout) {
    int ret;
    void *ptr;

    ndim_ = ndim;
    shape_.resize(ndim_);
    std::copy(dims, dims + ndim_, shape_.begin());
    elem_bits_ = GetDataTypeBits(type);
    if (strides == nullptr) {
        strides_ = ComputeStrides(shape_, elem_bits_);
    } else {
        strides_.resize(ndim_);
        std::copy(strides, strides + ndim_, strides_.begin());
    }
    layout_ = layout;
    type_ = type;
    rec_scale_ = 0;
    offset_ = 0;
    size_ = ComputeSize(shape_);
    buffer_size_ = (size_ * elem_bits_  + 7) / 8;

    ret = posix_memalign(&ptr, 4096, buffer_size_);
    if (ret != FTX_OK) {
        throw std::bad_alloc();
    }
    buffer_ = ptr;

}

ftxTensor::ftxTensor(const int *dims, const int *strides, size_t ndim, ftxDataType type,
        ftxDataLayout layout, void *data) {
    ndim_ = ndim;
    shape_.resize(ndim_);
    std::copy(dims, dims + ndim_, shape_.begin());
    elem_bits_ = GetDataTypeBits(type);
    if (strides == nullptr) {
        strides_ = ComputeStrides(shape_, elem_bits_);
    } else {
        strides_.resize(ndim_);
        std::copy(strides, strides + ndim_, strides_.begin());
    }
    layout_ = layout;
    type_ = type;
    rec_scale_ = 0;
    offset_ = 0;
    size_ = ComputeSize(shape_);
    buffer_size_ = (size_ * elem_bits_  + 7) / 8;

    buffer_ = data;
}

bool ftxTensor::IsPermValid(const std::vector<int> &perm) {
    // use static array for ndim ≤ 256
    bool seen[256] = {0};
    int ndim = perm.size();

    if (ndim != static_cast<int>(ndim_)) return false;
    if (ndim > 256) return false;

    for (int i = 0; i < ndim; ++i) {
        if (perm[i] < 0 || perm[i] >= ndim || seen[perm[i]])
            return false;
        seen[perm[i]] = true;
    }
    return true;
}

bool ftxTensor::IsShapeValid(const std::vector<int> &new_shape) {
    return ComputeSize(new_shape) == size_;
}

bool ftxTensor::IsContiguous() const {
    int expected_stride = 1 * elem_bits_ / 8;
    for (int i = ndim_ - 1; i >= 0; --i) {
        if (shape_[i] > 1 && strides_[i] != expected_stride)
            return false;
        expected_stride *= shape_[i];
    }
    return true;
}

void ftxTensor::Reshape(const std::vector<int> &new_shape, ftxTensor *out) {
    if (!IsShapeValid(new_shape)) {
        throw std::invalid_argument("Reshape error: new_shape does not match!!!");
    }

    if (!IsContiguous() && out != nullptr) {
        Contiguous(out);
        out->ndim_ = new_shape.size();
        out->shape_.resize(out->ndim_);
        std::copy(new_shape.begin(), new_shape.end(), out->shape_.begin());
        out->strides_ = ComputeStrides(out->shape_, out->elem_bits_);
    } else if (!IsContiguous() && out == nullptr) {
        throw std::invalid_argument("Reshape error: out tensor must be given if self tensor is not contiguous!!!");
    } else {
        ndim_ = new_shape.size();
        shape_.resize(ndim_);
        std::copy(new_shape.begin(), new_shape.end(), shape_.begin());
        strides_ = ComputeStrides(shape_, elem_bits_);
    }
}

void ftxTensor::Transpose(const std::vector<int> &perm) {
    if (!IsPermValid(perm)) {
        throw std::invalid_argument("Transpose error: dimension does not match!!!");
    }

    // prepare new shape and new strides
    std::vector<int> new_shape(ndim_);
    std::vector<int> new_strides(ndim_);
    for (uint32_t i = 0; i < ndim_; ++i) {
        new_shape[i] = shape_[perm[i]];
        new_strides[i] = strides_[perm[i]];
    }

    strides_ = new_strides;
    shape_ = new_shape;
}

void ftxTensor::Contiguous(ftxTensor *out) {
    // compute new strides for indexing
    std::vector<int> new_strides = ComputeStrides(shape_, elem_bits_);

    #pragma omp parallel for
    for (uint32_t i = 0; i < size_; i++) {
        // convert flat index to multi-dimensional index using new strides
        std::vector<int> index = OffsetToIndex(i, shape_);

        // convert multi-dimensional index to flat offset using old strides
        int in_offset = IndexToOffset(index, strides_, elem_bits_);

        // copy data at old index to new index
        if (type_ == FTX_INT32) {
            int32_t *in_ptr = static_cast<int32_t *>(buffer_);
            int32_t *out_ptr = static_cast<int32_t *>(out->Get());
            out_ptr[i] = in_ptr[in_offset];
        } else if (type_ == FTX_FP32) {
            float *in_ptr = static_cast<float *>(buffer_);
            float *out_ptr = static_cast<float *>(out->Get());
            out_ptr[i] = in_ptr[in_offset];
        } else if (type_ == FTX_FP16) {
            float16 *in_ptr = static_cast<float16 *>(buffer_);
            float16 *out_ptr = static_cast<float16 *>(out->Get());
            out_ptr[i] = in_ptr[in_offset];
        } else {
            int8_t *in_ptr = static_cast<int8_t *>(buffer_);
            int8_t *out_ptr = static_cast<int8_t *>(out->Get());
            out_ptr[i] = in_ptr[in_offset];
        }
    }

    out->layout_ = layout_;
    out->type_ = type_;
    out->shape_ = shape_;
    out->ndim_ = ndim_;
    out->type_ = type_;
    out->strides_ = new_strides;
}

void ftxTensor::Dump() const {
    LOG_INFO << std::dec << "size: " << size_ << "\n";
    LOG_INFO << "ndim: " << ndim_ << "\n";
    LOG_INFO << "shape: ";
    for (auto item : shape_)
        LOG_INFO << item << " ";
    LOG_INFO << "\n";
    LOG_INFO << "strides: ";
    for (auto item : strides_)
        LOG_INFO << item << " ";
    LOG_INFO << "\n";

    int ndim = static_cast<int>(ndim_);
    for (uint32_t i = 0; i < size_; i++) {
        int tmp = i;
        for (int d = ndim - 1; d >= 0; d--) {
            if (tmp % shape_[d] == 0) {
                LOG_INFO << "[";
                tmp /= shape_[d];
            } else {
                break;
            }
        }

        // convert flat index to multi-dimensional index
        std::vector<int> index(ndim);
        tmp = i;
        for (int d = ndim - 1; d >= 0; d--) {
            index[d] = tmp % shape_[d];
            tmp /= shape_[d];
        }

        // retrieve the actual offset with index and strides
        int in_offset = IndexToOffset(index, strides_, elem_bits_);
        if (type_ == FTX_INT32) {
            const int *ptr = static_cast<const int *>(buffer_);
            LOG_INFO << std::dec << ptr[in_offset];
        } else if (type_ == FTX_FP32) {
            const float *ptr = static_cast<const float *>(buffer_);
            LOG_INFO << std::fixed << ptr[in_offset];
        } else if (type_ == FTX_FP16) {
            const float16 *ptr = static_cast<const float16 *>(buffer_);
            LOG_INFO << std::fixed << FP16ToFP32(ptr[in_offset]);
        } else {
            const int8_t *ptr = static_cast<const int8_t *>(buffer_);
            LOG_INFO << std::dec << static_cast<int>(ptr[in_offset]);
        }

        tmp = i + 1;
        for (int d = ndim - 1; d >= 0; d--) {
            if (tmp % shape_[d] == 0) {
                LOG_INFO << "]";
                tmp /= shape_[d];
            } else {
                LOG_INFO << ", ";
                break;
            }
        }
    }
    LOG_INFO << "\n";
}
