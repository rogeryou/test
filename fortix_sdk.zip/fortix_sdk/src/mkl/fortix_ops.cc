// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <math.h>
#include "mkl.h"

#include "fortix.h"
#include "fortix_private.h"

ftxStatus ftxRMSNorm(ftxTensor *self, ftxTensor *gamma, float epsilon,
                     ftxTensor *out) {
    if (self->Get() == nullptr || gamma->Get() == nullptr ||
        out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *g_vec = static_cast<float *>(gamma->Get());
        float *output = static_cast<float *>(out->Get());
        size_t n = self->Size();

        // Compute sum of squares: dot(x, x)
        float sum_sq = cblas_sdot(n, input, 1, input, 1);
        float scale = 1.0f / sqrtf(sum_sq / n + epsilon);

        // Scale vector: x = x / rms
        vsMul(n, input, g_vec, output);

        cblas_sscal(n, scale, output, 1);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSwiglu(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32){
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());
        size_t n =  self->Size();

        cblas_scopy(n, input, 1, output, 1);
        cblas_sscal(n, -1.0f, output, 1);

        // exp
        vsExp(n, output, output);

        #pragma omp parallel for
        for (size_t i = 0; i < n; i++) {
            output[i] = output[i] + 1.0f;
        }
        if(other) {
           float *otherf = static_cast<float *>(other->Get());
           vsDiv(n, input, output, output);
           vsMul(n, other, output, output)
        } else {
            vsDiv(n, input, output, output);
        }

        return FTX_OK;
    }
    else{
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxSoftmax(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *x = static_cast<float *>(self->Get());
        float *o = static_cast<float *>(out->Get());
        size_t n = self->Size();

        // find max value (for numerical stability)
        float max_val = x[0];
        #pragma omp parallel for reduction(max:max_val)
        for (size_t i = 1; i < n; i++) {
            if (x[i] > max_val) {
                max_val = x[i];
            }
        }

        #pragma omp parallel for
        for (size_t i = 0; i < n; i++) {
            o[i] = x[i] - max_val;
        }

        // exp
        vsExp(n, o, o);

        // sum
        float sum = 0.0f;
        #pragma omp parallel for reduction(+:sum)
        for (size_t i = 0; i < n; i++) {
            sum += o[i];
        }

        float scale = 1.0f / sum;
        cblas_sscal(n, scale, o, 1);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxEmbedding(ftxTensor *weight, const int *indices, size_t n_indices, ftxTensor *out){
    if (weight->Get() == nullptr || indices == nullptr ||
        out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (weight->Type()==FTX_FP32){
        const float *input = static_cast<float *>(weight->Get());
        float *output = static_cast<float *>(out->Get());
        int embed_dim = weight->Shape()[1];
        for(size_t i = 0; i < n_indices; i++){
           int token_id = indices[i];
           cblas_scopy(embed_dim, &input[token_id * embed_dim], 1, &output[i * embed_dim], 1);
        }
    }
    else{
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxCos(ftxTensor *self, ftxTensor *out){
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }
    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());
        size_t n = self->Size();

        vsCos(n, input, output);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSin(ftxTensor *self, ftxTensor *out){
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }
    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());
        size_t n = self->Size();

        vsSin(n, input, output);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxRope(ftxTensor *self, int pos, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    size_t ndim = self->GetNDim();
    int size = self->Shape()[ndim - 1];
    if (size % 2 == 1) {
        return FTX_INVALID_INPUT;
    }

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());

        int half_size = size / 2;
        float *cos_vals = (float *)mkl_malloc(sizeof(float) * half_size, 64);
        float *sin_vals = (float *)mkl_malloc(sizeof(float) * half_size, 64);

        #pragma omp parallel for
        for (int i = 0; i < half_size; i++) {
            output[i] = pos * powf(10000.0f, -(float)i / half_size);
        }

        vsSin(half_size, output, sin_vals);
        vsCos(half_size, output, cos_vals);

        #pragma omp parallel for
        for (int i = 0; i < half_size; i++) {
            float xi0 = input[2 * i];
            float xi1 = input[2 * i + 1];

            output[2 * i]     = xi0 * cos_vals[i] - xi1 * sin_vals[i];
            output[2 * i + 1] = xi0 * sin_vals[i] + xi1 * cos_vals[i];
        }

        mkl_free(cos_vals);
        mkl_free(sin_vals);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxAdd(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32 && other->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());
        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *selff = static_cast<float*>(self->Get());
        float *otherf = static_cast<float*>(other->Get());
        float *outf = static_cast<float*>(out->Get());

        if(BcastType == FTX_BROADCAST_NONE) {
            vsAdd(out->Size(), selff, otherf, outf);
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                #pragma omp parallel for
                for(size_t i = 0; i < loop; i++){
                    vsAdd(vlen, selff, otherf + (vlen * i), outf + (vlen * i));
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();

                #pragma omp parallel for
                for(size_t i = 0; i < loop; i++){
                    vsAdd(vlen, selff + (vlen * i), otherf, outf + (vlen * i));
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape());
            vector<int> stride_A = ComputeStrides(self->Shape());
            vector<int> stride_B = ComputeStrides(other->Shape());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            // Compute bcast elementwise add
            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            #pragma omp parallel for
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] +
                          otherf[index_B / elem_bytes_B];
            }
            return FTX_OK;
        }
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxSub(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}

ftxStatus ftxMul(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}

ftxStatus ftxDiv(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}
