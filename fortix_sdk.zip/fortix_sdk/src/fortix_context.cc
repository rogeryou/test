// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <memory>
#include <cmath>

#include "fortix.h"
#include "fortix_private.h"

ftxContext::ftxContext() {
    // setup dCIM timings in ns
    mac_time_map_.emplace(256, 1400);
    mac_time_map_.emplace(512, 1800);
    mac_time_map_.emplace(1024, 3580);
    mac_time_map_.emplace(2048, 11020);
    mac_time_map_.emplace(4096, 40420);

}

ftxStatus ftxContext::setGEMMSize(uint32_t size) {
    auto iter = mac_time_map_.find(size);

    if (iter == mac_time_map_.end()) {
        return FTX_INVALID_INPUT;
    }

    gemm_size_ = size;

    // set timing according to GEMM size
    one_mac_time_ = (gemm_size_ / input_bw_ * 1000000.0f) +
                    tMAC_ + mac_time_map_[size];

    return FTX_OK;
}

void ftxContext::calcGEMMStats(size_t m, size_t k, size_t n) {
    record r;
    size_t k_tiled = std::ceil((double)k / gemm_size_);
    size_t n_tiled = std::ceil((double)n / gemm_size_);
    r.m = m;
    r.k = k;
    r.n = n;
    r.gemv_count = m * k_tiled * n_tiled;
    r.estimated_time =  r.gemv_count * one_mac_time_;

    stats_.push_back(r);
}

void ftxContext::showStats() {
    printf("m, k, n, gemv_count, estimated_time(s),\n");
    for (auto& r : stats_) {
        printf("%lu, %lu, %lu, %lu, %.9lf,\n",
               r.m, r.k, r.n, r.gemv_count, r.estimated_time / 1000000000.0);
    }
}
