// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <math.h>
#include "cblas.h"

#include "fortix.h"
#include "fortix_private.h"

ftxStatus ftxRMSNorm(ftxTensor *self, ftxTensor *gamma, float epsilon,
                     ftxTensor *out) {
    if (self->Get() == nullptr || gamma->Get() == nullptr ||
        out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *in_vec = static_cast<float *>(self->Get());
        float *g_vec = static_cast<float *>(gamma->Get());
        float *out_vec = static_cast<float *>(out->Get());
        size_t n = self->Size();

        // Compute sum of squares: dot(x, x)
        float sum_sq = cblas_sdot(n, in_vec, 1, in_vec, 1);
        float scale = 1.0f / sqrtf(sum_sq / n + epsilon);

        // Scale vector: x = x / rms
        #pragma omp parallel for
        for (size_t j = 0; j < n; j++) {
            out_vec[j] = g_vec[j] * in_vec[j];
        }
        cblas_sscal(n, scale, out_vec, 1);
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

// openblas couldn't implent silu
ftxStatus ftxSwiglu(ftxTensor *self, ftxTensor *other, ftxTensor *out)  {
    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());
        if(other) {
            float *otherf = static_cast<float*>(other->Get());
            #pragma omp parallel for
            for(size_t i = 0; i < self->Size(); i++) {
                output[i] = (otherf[i] * input[i])/(1.0 + expf32(-input[i]));
            }
        } else {
            #pragma omp parallel for
            for(size_t i = 0; i < self->Size(); i++) {
                output[i] = input[i]/(1.0 + expf32(-input[i]));
            }
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSoftmax(ftxTensor *self, ftxTensor *out) {

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());
        float sum_up = 0.0;
        float max_value = input[cblas_ismax(self->Size(), input, 1)];

        #pragma omp parallel for reduction(+:sum_up)
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = expf32(input[i] - max_value);
            sum_up += output[i];
        }

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = output[i] / sum_up;
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxEmbedding(ftxTensor *weight, const int *indices, size_t n_indices, ftxTensor *out) {
    if (weight->Get() == nullptr || indices == nullptr
        || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }
    if (weight->Type() == FTX_FP32) {
        const float *input = static_cast<float*>(weight->Get());
        float *output = static_cast<float*>(out->Get());
        int embed_dim = weight->Shape()[1];

        #pragma omp parallel for
        for(size_t i = 0; i < n_indices; i++) {
           int token_id = indices[i];
           cblas_scopy(embed_dim, &input[token_id * embed_dim], 1, &output[i * embed_dim], 1);
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxCos(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }
    if (self->Type() == FTX_FP32) {
        float *inputf = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = cosf(inputf[i]);
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}
ftxStatus ftxSin(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *inputf = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = sinf(inputf[i]);
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}
ftxStatus ftxRope(ftxTensor *self, int pos, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    size_t ndim = self->GetNDim();
    int size = self->Shape()[ndim - 1];

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());

        int half_size = size / 2;
        for (int i = 0; i < size; i += 2) {
            int index = i / 2;
            float theta = pow(10000.0, -(float)index / half_size);
            float angle = pos * theta;

            float cos_theta = cosf(angle);
            float sin_theta = sinf(angle);

            float x0 = input[i];
            float x1 = input[i + 1];

            output[i]     = x0 * cos_theta - x1 * sin_theta;
            output[i + 1] = x0 * sin_theta + x1 * cos_theta;
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxAdd(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32 && other->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());
        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *selff = static_cast<float*>(self->Get());
        float *otherf = static_cast<float*>(other->Get());
        float *outf = static_cast<float*>(out->Get());

        if(BcastType == FTX_BROADCAST_NONE) {
            cblas_scopy(self->Size(), selff, 1, outf, 1);
            cblas_saxpy(out->Size(), 1, otherf, 1, outf, 1);
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                cblas_scopy(other->Size(), otherf, 1, outf, 1);

                #pragma omp parallel for
                for(size_t i = 0; i < loop; i++){
                    cblas_saxpy(vlen, 1, selff, 1, outf + (vlen * i), 1);
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();

                cblas_scopy(self->Size(), selff, 1, outf, 1);

                #pragma omp parallel for
                for(size_t i = 0; i < loop; i++){
                    cblas_saxpy(vlen, 1, otherf, 1, outf + (vlen * i), 1);
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape());
            vector<int> stride_A = ComputeStrides(self->Shape());
            vector<int> stride_B = ComputeStrides(other->Shape());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            // Compute bcast elementwise add
            #pragma omp parallel for
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] +
                          otherf[index_B / elem_bytes_B];
            }
            return FTX_OK;
        }
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxSub(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}

ftxStatus ftxMul(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}

ftxStatus ftxDiv(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    return FTX_OK;
}
