#include <stdbool.h>
#include <stdint.h>
#include <immintrin.h>
#include <string.h>
#include <math.h>
#include <cassert>


#include "fortix.h"
#include "fortix_private.h"
#include "cpu/quant.h"
#include "cpu/matmul.h"

#define UNROLL 4
#define BLOCKSIZE 64

void f32_quant_q8(ftxTensor *src, int block_size, ftxTensor *q_data, ftxTensor *scale) {
    
    int k = src->Shape().back();
    
    // assert(k % block_size == 0);
    const int nb = scale->Shape().back();
    int out_loop = src->Size() / k;

    assert(src->Type() == FTX_FP32 && q_data->Type() == FTX_INT8 && scale->Type() == FTX_FP32);

    float *src_fp32 = static_cast<float*>(src->Get());
    int8_t *src_q8 = static_cast<int8_t*>(q_data->Get());
    float *scale_fp32 = static_cast<float*>(scale->Get());
    
    #pragma omp parallel for
    for (int o = 0; o < out_loop; o++) {
        for (int i = 0; i < nb; i++) {
            float abmax = 0.0f; // absolute max

            for (int j = 0; j < min(block_size, (k - i * block_size)); j++) {
                const float v = src_fp32[o * k + i * block_size + j];
                abmax = MAX(abmax, fabsf(v));
            }

            const float d = abmax / ((1 << 7) - 1);
            float s = d ? 1.0f/d : 0.0f;
            scale_fp32[o * nb + i] = d;
            for (int j = 0; j < min(block_size, (k - i * block_size)); j++) {
                const float x0 = src_fp32[o * k + i * block_size + j] * s;

                src_q8[o * k + i * block_size + j] = roundf(x0);
            }
        }
    }
}