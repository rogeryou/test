// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <stdbool.h>
#include <stdint.h>
#include <immintrin.h>
#include <string.h>
#include <cassert>


#include "fortix.h"
#include "fortix_private.h"
#include "cpu/matmul.h"

#define UNROLL 4
#define BLOCKSIZE 64

void do_block_avx2_i8i8(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const int8_t* A, const int8_t* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    int8_t B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(&B_cont[l], &B[k * N + sj], n_blocksize * sizeof(int8_t));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 32 <= sj + n_blocksize && l + 32 <= n_blocksize;
             j += 32, l += 32) {
            __m256i a_vec, b_vec;
            __m256i c_vec[4];

            c_vec[0] = _mm256_cvtps_epi32(_mm256_loadu_ps(C + i * N + j));
            c_vec[1] = _mm256_cvtps_epi32(_mm256_loadu_ps(C + i * N + j + 8));
            c_vec[2] = _mm256_cvtps_epi32(_mm256_loadu_ps(C + i * N + j + 16));
            c_vec[3] = _mm256_cvtps_epi32(_mm256_loadu_ps(C + i * N + j + 24));

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                a_vec = _mm256_set1_epi8(A[i * K + k]);
                b_vec = _mm256_loadu_si256((__m256i*)(B_cont + q * n_blocksize + l));

                // Extend to int16_t
                __m256i a_lo = _mm256_cvtepi8_epi16(_mm256_castsi256_si128(a_vec));
                __m256i a_hi = _mm256_cvtepi8_epi16(_mm256_extracti128_si256(a_vec, 1));

                __m256i b_lo = _mm256_cvtepi8_epi16(_mm256_castsi256_si128(b_vec));
                __m256i b_hi = _mm256_cvtepi8_epi16(_mm256_extracti128_si256(b_vec, 1));

                // Multiply
                __m256i prod_lo = _mm256_mullo_epi16(a_lo, b_lo);
                __m256i prod_hi = _mm256_mullo_epi16(a_hi, b_hi);

                // Sum into 32-bit integers
                __m256i prod32_lo = _mm256_cvtepi16_epi32(_mm256_castsi256_si128(prod_lo));
                __m256i prod32_hi = _mm256_cvtepi16_epi32(_mm256_extracti128_si256(prod_lo, 1));

                __m256i prod32_lo2 = _mm256_cvtepi16_epi32(_mm256_castsi256_si128(prod_hi));
                __m256i prod32_hi2 = _mm256_cvtepi16_epi32(_mm256_extracti128_si256(prod_hi, 1));

                c_vec[0] = _mm256_add_epi32(prod32_lo, c_vec[0]);
                c_vec[1] = _mm256_add_epi32(prod32_hi, c_vec[1]);
                c_vec[2] = _mm256_add_epi32(prod32_lo2, c_vec[2]);
                c_vec[3] = _mm256_add_epi32(prod32_hi2, c_vec[3]);
            }

            _mm256_storeu_ps(C + i * N + j, _mm256_cvtepi32_ps(c_vec[0]));
            _mm256_storeu_ps(C + i * N + j + 8, _mm256_cvtepi32_ps(c_vec[1]));
            _mm256_storeu_ps(C + i * N + j + 16, _mm256_cvtepi32_ps(c_vec[2]));
            _mm256_storeu_ps(C + i * N + j + 24, _mm256_cvtepi32_ps(c_vec[3]));
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            float sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += (float)A[i * K + k] * (float)B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_i8i8f32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_i8i8(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

void do_block_avx2_i8f32(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const int8_t* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    float B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(B_cont + l, B + k * N + sj, n_blocksize * sizeof(float));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 8 * UNROLL <= sj + n_blocksize && l + 8 * UNROLL <= n_blocksize;
             j += 8 * UNROLL, l += 8 * UNROLL) {
            __m256 a_vec;
            __m256 c_vec[UNROLL];

            c_vec[0] = _mm256_loadu_ps(C + i * N + j);
            c_vec[1] = _mm256_loadu_ps(C + i * N + j + 8);
            c_vec[2] = _mm256_loadu_ps(C + i * N + j + 16);
            c_vec[3] = _mm256_loadu_ps(C + i * N + j + 24);

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                a_vec = _mm256_set1_ps((float)A[i * K + k]);
                c_vec[0] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l), c_vec[0]);
                c_vec[1] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 8), c_vec[1]);
                c_vec[2] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 16), c_vec[2]);
                c_vec[3] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 24), c_vec[3]);
            }

            _mm256_storeu_ps(C + i * N + j, c_vec[0]);
            _mm256_storeu_ps(C + i * N + j + 8, c_vec[1]);
            _mm256_storeu_ps(C + i * N + j + 16, c_vec[2]);
            _mm256_storeu_ps(C + i * N + j + 24, c_vec[3]);
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            float sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += (float)A[i * K + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_i8f32f32(size_t M, size_t K, size_t N, const int8_t* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_i8f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

static inline float hsum_float_8(const __m256 x) {
    __m128 res = _mm256_extractf128_ps(x, 1);
    res = _mm_add_ps(res, _mm256_castps256_ps128(x));
    res = _mm_add_ps(res, _mm_movehl_ps(res, res));
    res = _mm_add_ss(res, _mm_movehdup_ps(res));
    return _mm_cvtss_f32(res);
}

float vec_dot_avx2_i8f32(size_t n, const int8_t *a, const float *b, float acc) {
    __m256 acc_vec = _mm256_setzero_ps();  // accumulator for 8 float32 results
    size_t i = 0;
    float sumf = 0.0f;

    for (i = 0; i + 32 <= n; i += 32) {
        // Load 32 int8_t values
        __m256i a_i8 = _mm256_loadu_si256((const __m256i*)(a + i)); // 32 x int8_t

        // Split into two 128-bit chunks, sign-extend to 16-bit
        __m128i low_i8  = _mm256_extracti128_si256(a_i8, 0); // lower 128 bits
        __m128i high_i8 = _mm256_extracti128_si256(a_i8, 1); // upper 128 bits

        __m256i a_i16_lo = _mm256_cvtepi8_epi16(low_i8);  // 16 x int16_t -> lower 16
        __m256i a_i16_hi = _mm256_cvtepi8_epi16(high_i8); // 16 x int16_t -> upper 16

        // Convert to float
        __m256 a_f32_lo = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_lo, 0)));
        __m256 a_f32_hi = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_lo, 1)));
        __m256 a_f32_lo2 = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_hi, 0)));
        __m256 a_f32_hi2 = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_hi, 1)));

        // Load corresponding 32 float values from y
        __m256 b0 = _mm256_loadu_ps(b + i);
        __m256 b1 = _mm256_loadu_ps(b + i + 8);
        __m256 b2 = _mm256_loadu_ps(b + i + 16);
        __m256 b3 = _mm256_loadu_ps(b + i + 24);

        // Multiply and accumulate
        acc_vec = _mm256_fmadd_ps(a_f32_lo, b0, acc_vec);
        acc_vec = _mm256_fmadd_ps(a_f32_hi, b1, acc_vec);
        acc_vec = _mm256_fmadd_ps(a_f32_lo2, b2, acc_vec);
        acc_vec = _mm256_fmadd_ps(a_f32_hi2, b3, acc_vec);
    }

    // Horizontal sum of acc (8 floats)
    sumf = hsum_float_8(acc_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += (float)(a[i]) * b[i];

    return sumf + acc;
}

void do_block_avx2_bt_i8f32(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const int8_t* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_i8f32(k_blocksize, (A + i * K + sk), (B + j * K + sk), C[i * N + j]);
        }
    }
}

void matmul_bt_i8f32f32(size_t M, size_t K, size_t N, const int8_t* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_bt_i8f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

// add int16_t pairwise and return as float vector
static inline __m256 sum_i16_pairs_float(const __m256i x) {
    const __m256i ones = _mm256_set1_epi16(1);
    const __m256i summed_pairs = _mm256_madd_epi16(ones, x);
    return _mm256_cvtepi32_ps(summed_pairs);
}

static inline __m256 mul_sum_us8_pairs_float(const __m256i ax, const __m256i sy) {
#if defined(__AVX512VNNI__) && defined(__AVX512VL__)
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbusd_epi32(zero, ax, sy);
    return _mm256_cvtepi32_ps(summed_pairs);
#elif defined(__AVXVNNI__)
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbusd_avx_epi32(zero, ax, sy);
    return _mm256_cvtepi32_ps(summed_pairs);
#else
    // Perform multiplication and create 16-bit values
    const __m256i dot = _mm256_maddubs_epi16(ax, sy);
    return sum_i16_pairs_float(dot);
#endif
}

// multiply int8_t, add results pairwise twice and return as float vector
static inline __m256 mul_sum_i8_pairs_float(const __m256i x, const __m256i y) {
#if __AVXVNNIINT8__
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbssd_epi32(zero, x, y);
    return _mm256_cvtepi32_ps(summed_pairs);
#else
    // Get absolute values of x vectors
    const __m256i ax = _mm256_sign_epi8(x, x);
    // Sign the values of the y vectors
    const __m256i sy = _mm256_sign_epi8(y, x);
    return mul_sum_us8_pairs_float(ax, sy);
#endif
}

float vec_dot_avx2_i8i8(size_t n, const int8_t* a, const int8_t* b, float acc) {
    // Initialize accumulator with zeros
    __m256 sum_vec = _mm256_setzero_ps();
    size_t i = 0;
    float sumf;

    // Main loop
    for (; i + 32 <= n; i += 32) {
        __m256i qa = _mm256_loadu_si256((const __m256i *)(a + i));
        __m256i qb = _mm256_loadu_si256((const __m256i *)(b + i));

        const __m256 q = mul_sum_i8_pairs_float(qa, qb);

        // Multiply q with scale and accumulate
        sum_vec = _mm256_add_ps(q, sum_vec);
    }

    sumf = hsum_float_8(sum_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += (float)(a[i] * b[i]);

    return sumf + acc;
}

void do_block_avx2_bt_i8i8(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const int8_t* A, const int8_t* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_i8i8(k_blocksize, (A + i * K + sk), (B + j * K + sk), C[i * N + j]);
        }
    }
}

void matmul_bt_i8i8f32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                // printf("si = %ld sj = %ld sk = %ld\n", si, sj, sk);
                do_block_avx2_bt_i8i8(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}


void do_block_avx2_i8i8i32(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const int8_t* A, const int8_t* B, int32_t* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    int8_t B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(&B_cont[l], &B[k * N + sj], n_blocksize * sizeof(int8_t));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 32 <= sj + n_blocksize && l + 32 <= n_blocksize;
             j += 32, l += 32) {
            __m256i a_vec, b_vec;
            __m256i c_vec[4];

            c_vec[0] = _mm256_loadu_si256((__m256i*)(C + i * N + j));
            c_vec[1] = _mm256_loadu_si256((__m256i*)(C + i * N + j + 8));
            c_vec[2] = _mm256_loadu_si256((__m256i*)(C + i * N + j + 16));
            c_vec[3] = _mm256_loadu_si256((__m256i*)(C + i * N + j + 24));

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                a_vec = _mm256_set1_epi8(A[i * K + k]);
                b_vec = _mm256_loadu_si256((__m256i*)(B_cont + q * n_blocksize + l));

                // Extend to int16_t
                __m256i a_lo = _mm256_cvtepi8_epi16(_mm256_castsi256_si128(a_vec));
                __m256i a_hi = _mm256_cvtepi8_epi16(_mm256_extracti128_si256(a_vec, 1));

                __m256i b_lo = _mm256_cvtepi8_epi16(_mm256_castsi256_si128(b_vec));
                __m256i b_hi = _mm256_cvtepi8_epi16(_mm256_extracti128_si256(b_vec, 1));

                // Multiply
                __m256i prod_lo = _mm256_mullo_epi16(a_lo, b_lo);
                __m256i prod_hi = _mm256_mullo_epi16(a_hi, b_hi);

                // Sum into 32-bit integers
                __m256i prod32_lo = _mm256_cvtepi16_epi32(_mm256_castsi256_si128(prod_lo));
                __m256i prod32_hi = _mm256_cvtepi16_epi32(_mm256_extracti128_si256(prod_lo, 1));

                __m256i prod32_lo2 = _mm256_cvtepi16_epi32(_mm256_castsi256_si128(prod_hi));
                __m256i prod32_hi2 = _mm256_cvtepi16_epi32(_mm256_extracti128_si256(prod_hi, 1));

                c_vec[0] = _mm256_add_epi32(prod32_lo, c_vec[0]);
                c_vec[1] = _mm256_add_epi32(prod32_hi, c_vec[1]);
                c_vec[2] = _mm256_add_epi32(prod32_lo2, c_vec[2]);
                c_vec[3] = _mm256_add_epi32(prod32_hi2, c_vec[3]);
            }

            _mm256_storeu_si256((__m256i*)(C + i * N + j), c_vec[0]);
            _mm256_storeu_si256((__m256i*)(C + i * N + j + 8), c_vec[1]);
            _mm256_storeu_si256((__m256i*)(C + i * N + j + 16), c_vec[2]);
            _mm256_storeu_si256((__m256i*)(C + i * N + j + 24), c_vec[3]);
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            int32_t sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += A[i * K + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_i8i8i32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, int32_t* C) {
    memset(C, 0, M * N * sizeof(int32_t));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_i8i8i32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

static inline int32_t hsum_i32_8(const __m256i x) {
    __m128i lo = _mm256_castsi256_si128(x);           // lower 128 bits
    __m128i hi = _mm256_extracti128_si256(x, 1);       // upper 128 bits
    __m128i sum128 = _mm_add_epi32(lo, hi);            // sum pairs

    __m128i shuf = _mm_shuffle_epi32(sum128, _MM_SHUFFLE(2, 3, 0, 1));
    sum128 = _mm_add_epi32(sum128, shuf);              // add high-low

    shuf = _mm_shuffle_epi32(sum128, _MM_SHUFFLE(1, 0, 3, 2));
    sum128 = _mm_add_epi32(sum128, shuf);

    return _mm_cvtsi128_si32(sum128);                  // extract lowest int
}

// add int16_t pairwise and return as int32_t vector
static inline __m256i sum_i16_pairs_i32(const __m256i x) {
    const __m256i ones = _mm256_set1_epi16(1);
    const __m256i summed_pairs = _mm256_madd_epi16(ones, x);
    return summed_pairs;
}

static inline __m256i mul_sum_us8_pairs_i32(const __m256i ax, const __m256i sy) {
#if defined(__AVX512VNNI__) && defined(__AVX512VL__)
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbusd_epi32(zero, ax, sy);
    return summed_pairs;
#elif defined(__AVXVNNI__)
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbusd_avx_epi32(zero, ax, sy);
    return summed_pairs;
#else
    // Perform multiplication and create 16-bit values
    const __m256i dot = _mm256_maddubs_epi16(ax, sy);
    return sum_i16_pairs_i32(dot);
#endif
}

// multiply int8_t, add results pairwise twice and return as int32_t vector
static inline __m256i mul_sum_i8_pairs_i32(const __m256i x, const __m256i y) {
#if __AVXVNNIINT8__
    const __m256i zero = _mm256_setzero_si256();
    const __m256i summed_pairs = _mm256_dpbssd_epi32(zero, x, y);
    return summed_pairs;
#else
    // Get absolute values of x vectors
    const __m256i ax = _mm256_sign_epi8(x, x);
    // Sign the values of the y vectors
    const __m256i sy = _mm256_sign_epi8(y, x);
    return mul_sum_us8_pairs_i32(ax, sy);
#endif
}

int32_t vec_dot_avx2_i8i8i32(size_t n, const int8_t* a, const int8_t* b, int32_t acc) {
    // Initialize accumulator with zeros
    __m256i sum_vec = _mm256_setzero_si256();
    size_t i = 0;
    int32_t sumf;

    // Main loop
    for (; i + 32 <= n; i += 32) {
        __m256i qa = _mm256_loadu_si256((const __m256i *)(a + i));
        __m256i qb = _mm256_loadu_si256((const __m256i *)(b + i));

        const __m256i q = mul_sum_i8_pairs_i32(qa, qb);

        // Multiply q with scale and accumulate
        sum_vec = _mm256_add_epi32(q, sum_vec);
    }

    sumf = hsum_i32_8(sum_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += a[i] * b[i];

    return sumf + acc;
}

void do_block_avx2_bt_i8i8i32(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const int8_t* A, const int8_t* B, int32_t* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_i8i8i32(k_blocksize, (A + i * K + sk), (B + j * K + sk), C[i * N + j]);
        }
    }
}

void matmul_bt_i8i8i32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, int32_t* C) {
    memset(C, 0, M * N * sizeof(int32_t));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                // printf("si = %ld sj = %ld sk = %ld\n", si, sj, sk);
                do_block_avx2_bt_i8i8i32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

float vec_dot_avx2_f16f32(size_t n, const float16 *a, const float *b, float acc) {
    __m256 acc_vec = _mm256_setzero_ps();  // accumulator for 8 float32 results
    size_t i = 0;
    float sumf = 0.0f;

    for (i = 0; i + 8 <= n; i += 8) {
        // Load 8 float16 values
        __m128i a_f16 = _mm_loadu_si128((__m128i*)(a + i)); // 8 x float16
        __m256 a_f32 = _mm256_cvtph_ps(a_f16);

        // Load 8 float32 values
        __m256 b_f32 = _mm256_loadu_ps(b + i);

        // Multiply and accumulate
        acc_vec = _mm256_fmadd_ps(a_f32, b_f32, acc_vec);
    }

    // Horizontal sum of acc (8 floats)
    sumf = hsum_float_8(acc_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += FP16ToFP32(a[i]) * b[i];

    return sumf + acc;
}

void do_block_avx2_bt_f16f32(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const float16* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_f16f32(k_blocksize, (A + i * K + sk), (B + j * K + sk), C[i * N + j]);
        }
    }
}

void matmul_bt_f16f32f32(size_t M, size_t K, size_t N, const float16* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_bt_f16f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

void do_block_avx2_f16f32(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const float16* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    float B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(B_cont + l, B + k * N + sj, n_blocksize * sizeof(float));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 8 * UNROLL <= sj + n_blocksize && l + 8 * UNROLL <= n_blocksize;
             j += 8 * UNROLL, l += 8 * UNROLL) {
            __m128i a_vec_ph;
            __m256 a_vec;
            __m256 c_vec[UNROLL];
            float16 tmp;

            c_vec[0] = _mm256_loadu_ps(C + i * N + j);
            c_vec[1] = _mm256_loadu_ps(C + i * N + j + 8);
            c_vec[2] = _mm256_loadu_ps(C + i * N + j + 16);
            c_vec[3] = _mm256_loadu_ps(C + i * N + j + 24);

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                tmp = A[i * K + k];
                a_vec_ph = _mm_setr_epi16(tmp, tmp, tmp, tmp, tmp, tmp, tmp, tmp);
                a_vec = _mm256_cvtph_ps(a_vec_ph);
                c_vec[0] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l), c_vec[0]);
                c_vec[1] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 8), c_vec[1]);
                c_vec[2] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 16), c_vec[2]);
                c_vec[3] = _mm256_fmadd_ps(a_vec, _mm256_loadu_ps(B_cont + q * n_blocksize + l + 24), c_vec[3]);
            }

            _mm256_storeu_ps(C + i * N + j, c_vec[0]);
            _mm256_storeu_ps(C + i * N + j + 8, c_vec[1]);
            _mm256_storeu_ps(C + i * N + j + 16, c_vec[2]);
            _mm256_storeu_ps(C + i * N + j + 24, c_vec[3]);
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            float sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += FP16ToFP32(A[i * K + k]) * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_f16f32f32(size_t M, size_t K, size_t N, const float16* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_f16f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

float vec_dot_avx2_f32f16(size_t n, const float *a, const float16 *b, float acc) {
    __m256 acc_vec = _mm256_setzero_ps();  // accumulator for 8 float32 results
    size_t i = 0;
    float sumf = 0.0f;

    for (i = 0; i + 8 <= n; i += 8) {
        // Load 8 float32 values
        __m256 a_f32 = _mm256_loadu_ps(a + i);

        // Load 8 float16 values
        __m128i b_f16 = _mm_loadu_si128((__m128i*)(b + i)); // 8 x float16
        __m256 b_f32 = _mm256_cvtph_ps(b_f16);

        // Multiply and accumulate
        acc_vec = _mm256_fmadd_ps(a_f32, b_f32, acc_vec);
    }

    // Horizontal sum of acc (8 floats)
    sumf = hsum_float_8(acc_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += a[i] * FP16ToFP32(b[i]);

    return sumf + acc;
}

void do_block_avx2_bt_f32f16(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const float* A, const float16* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_f32f16(k_blocksize,
                                              (A + i * K + sk),
                                              (B + j * K + sk),
                                              C[i * N + j]);
        }
    }
}

void matmul_bt_f32f16f32(size_t M, size_t K, size_t N, const float* A, const float16* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_bt_f32f16(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

void do_block_avx2_f32f16(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const float* A, const float16* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    float16 B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(B_cont + l, B + k * N + sj, n_blocksize * sizeof(float16));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 8 * UNROLL <= sj + n_blocksize && l + 8 * UNROLL <= n_blocksize;
             j += 8 * UNROLL, l += 8 * UNROLL) {
            __m256 a_vec;
            __m128i b_vec_ph[UNROLL];
            __m256 c_vec[UNROLL];

            c_vec[0] = _mm256_loadu_ps(C + i * N + j);
            c_vec[1] = _mm256_loadu_ps(C + i * N + j + 8);
            c_vec[2] = _mm256_loadu_ps(C + i * N + j + 16);
            c_vec[3] = _mm256_loadu_ps(C + i * N + j + 24);

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                a_vec = _mm256_set1_ps(A[i * K + k]);
                b_vec_ph[0] = _mm_loadu_si128((__m128i*)(B_cont + q * n_blocksize + l));
                b_vec_ph[1] = _mm_loadu_si128((__m128i*)(B_cont + q * n_blocksize + l + 8));
                b_vec_ph[2] = _mm_loadu_si128((__m128i*)(B_cont + q * n_blocksize + l + 16));
                b_vec_ph[3] = _mm_loadu_si128((__m128i*)(B_cont + q * n_blocksize + l + 24));

                c_vec[0] = _mm256_fmadd_ps(a_vec, _mm256_cvtph_ps(b_vec_ph[0]), c_vec[0]);
                c_vec[1] = _mm256_fmadd_ps(a_vec, _mm256_cvtph_ps(b_vec_ph[1]), c_vec[1]);
                c_vec[2] = _mm256_fmadd_ps(a_vec, _mm256_cvtph_ps(b_vec_ph[2]), c_vec[2]);
                c_vec[3] = _mm256_fmadd_ps(a_vec, _mm256_cvtph_ps(b_vec_ph[3]), c_vec[3]);
            }

            _mm256_storeu_ps(C + i * N + j, c_vec[0]);
            _mm256_storeu_ps(C + i * N + j + 8, c_vec[1]);
            _mm256_storeu_ps(C + i * N + j + 16, c_vec[2]);
            _mm256_storeu_ps(C + i * N + j + 24, c_vec[3]);
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            float sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += A[i * K + k] * FP16ToFP32(B[k * N + j]);
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_f32f16f32(size_t M, size_t K, size_t N, const float* A, const float16* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_f32f16(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

// quantized matmul
float vec_dot_avx2_q8q8f32(size_t n, const int8_t* a_q, const float* a_s, const int8_t* b_q,const float* b_s, float acc,const int q_bsize,const int offset_s) {
    // Initialize accumulator with zeros
    __m256 sum_vec = _mm256_setzero_ps();
    size_t i = 0;
    float sumf = 0.0f;
    assert(offset_s == 0);
    // Main loop
    for (; i + 32 <= n; i += 32) {
        const __m256 d = _mm256_set1_ps((a_s[(i + offset_s) / q_bsize]) * (b_s[(i + offset_s) / q_bsize]));
        // printf("the x scale is %f\n", (double)a_s[(i + offset_s) / q_bsize] * (double)b_s[(i + offset_s) / q_bsize]);

        __m256i qa = _mm256_loadu_si256((const __m256i *)(a_q + i));
        __m256i qb = _mm256_loadu_si256((const __m256i *)(b_q + i));

        const __m256 q = mul_sum_i8_pairs_float(qa, qb);

        // Multiply q with scale and accumulate
        sum_vec = _mm256_fmadd_ps(d, q, sum_vec);
    }

    sumf = hsum_float_8(sum_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++) {
        sumf += a_q[i] * b_q[i] * a_s[(i + offset_s) / q_bsize] * b_s[(i + offset_s) / q_bsize];
    }

    return sumf + acc;
}

void do_block_avx2_bt_q8q8f32(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const int8_t* A_q, const float* A_s,
                      const int8_t* B_q, const float* B_s,
                      float* C, const int q_bsize) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;

    int stride_s = (K + q_bsize - 1) / q_bsize;
    int offset_s = 0;
    if(sk % q_bsize != 0) {
        printf("q need to offset, since rows %% blocksize != 0\n");
        offset_s = sk % q_bsize;
        assert(false);
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_q8q8f32(k_blocksize, (A_q + i * K + sk), (A_s + i * stride_s + sk/q_bsize),
                                        (B_q + j * K + sk), (B_s + j * stride_s + sk/q_bsize), C[i * N + j], q_bsize, offset_s);
        }
    }
}

void matmul_bt_q8q8f32(size_t M, size_t K, size_t N,
                        const int8_t* A_q, const float* A_s,
                        const int8_t* B_q, const float* B_s,
                        float* C, const int q_bsize) {
    memset(C, 0.0f, M * N * sizeof(float));

    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                // printf("si = %ld sj = %ld sk = %ld\n", si, sj, sk);
                do_block_avx2_bt_q8q8f32(M, K, N, si, sk, sj, A_q, A_s, B_q, B_s, C, q_bsize);
            }
        }
    }
}

void do_block_avx2_f32f32f32(size_t M, size_t K, size_t N,
                     size_t si, size_t sk, size_t sj,
                     const float* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    float B_cont[BLOCKSIZE * BLOCKSIZE];
    for (size_t k = sk, l = 0; k < sk + k_blocksize; k++) {
        memcpy(B_cont + l, B + k * N + sj, n_blocksize * sizeof(float));
        l += n_blocksize;
    }

    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        size_t j, l;
        for (j = sj, l = 0;
             j + 8 * UNROLL <= sj + n_blocksize && l + 8 * UNROLL <= n_blocksize;
             j += 8 * UNROLL, l += 8 * UNROLL) {
            __m256 a_vec;
            __m256 b_vec[UNROLL];
            __m256 c_vec[UNROLL];

            c_vec[0] = _mm256_loadu_ps(C + i * N + j);
            c_vec[1] = _mm256_loadu_ps(C + i * N + j + 8);
            c_vec[2] = _mm256_loadu_ps(C + i * N + j + 16);
            c_vec[3] = _mm256_loadu_ps(C + i * N + j + 24);

            for (size_t k = sk, q = 0; k < sk + k_blocksize && q < k_blocksize; k++, q++) {
                a_vec = _mm256_set1_ps(A[i * K + k]);
                b_vec[0] = _mm256_loadu_ps(B_cont + q * n_blocksize + l);
                b_vec[1] = _mm256_loadu_ps(B_cont + q * n_blocksize + l + 8);
                b_vec[2] = _mm256_loadu_ps(B_cont + q * n_blocksize + l + 16);
                b_vec[3] = _mm256_loadu_ps(B_cont + q * n_blocksize + l + 24);

                c_vec[0] = _mm256_fmadd_ps(a_vec, b_vec[0], c_vec[0]);
                c_vec[1] = _mm256_fmadd_ps(a_vec, b_vec[1], c_vec[1]);
                c_vec[2] = _mm256_fmadd_ps(a_vec, b_vec[2], c_vec[2]);
                c_vec[3] = _mm256_fmadd_ps(a_vec, b_vec[3], c_vec[3]);
            }

            _mm256_storeu_ps(C + i * N + j, c_vec[0]);
            _mm256_storeu_ps(C + i * N + j + 8, c_vec[1]);
            _mm256_storeu_ps(C + i * N + j + 16, c_vec[2]);
            _mm256_storeu_ps(C + i * N + j + 24, c_vec[3]);
        }

        // Tail-handling (scalar loop for remaining columns)
        for (; j < sj + n_blocksize; j++) {
            float sum = C[i * N + j];
            for (size_t k = sk; k < sk + k_blocksize; k++) {
                sum += A[i * K + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

void matmul_f32f32f32(size_t M, size_t K, size_t N, const float* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_f32f32f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}

float vec_dot_avx2_f32f32f32(size_t n, const float *a, const float *b, float acc) {
    __m256 acc_vec = _mm256_setzero_ps();  // accumulator for 8 float32 results
    size_t i = 0;
    float sumf = 0.0f;

    for (i = 0; i + 8 <= n; i += 8) {
        // Load 8 float32 values
        __m256 a_f32 = _mm256_loadu_ps(a + i);

        // Load 8 float16 values
        __m256 b_f32 = _mm256_loadu_ps(b + i); // 8 x float16

        // Multiply and accumulate
        acc_vec = _mm256_fmadd_ps(a_f32, b_f32, acc_vec);
    }

    // Horizontal sum of acc (8 floats)
    sumf = hsum_float_8(acc_vec);

    // Handle tail elements (n not multiple of 16)
    for (; i < n; i++)
        sumf += a[i] * b[i];

    return sumf + acc;
}

void do_block_avx2_bt_f32f32f32(size_t M, size_t K, size_t N,
                      size_t si, size_t sk, size_t sj,
                      const float* A, const float* B, float* C) {
    size_t m_blocksize = (M - si) < BLOCKSIZE ? (M - si) : BLOCKSIZE;
    size_t k_blocksize = (K - sk) < BLOCKSIZE ? (K - sk) : BLOCKSIZE;
    size_t n_blocksize = (N - sj) < BLOCKSIZE ? (N - sj) : BLOCKSIZE;
    for (size_t i = si; i < si + m_blocksize; i++) {
        // Vectorized columns
        for (size_t j = sj; j < sj + n_blocksize; j++) {
            C[i * N + j] = vec_dot_avx2_f32f32f32(k_blocksize,
                                                  (A + i * K + sk),
                                                  (B + j * K + sk),
                                                  C[i * N + j]);
        }
    }
}

void matmul_bt_f32f32f32(size_t M, size_t K, size_t N, const float* A, const float* B, float* C) {
    memset(C, 0, M * N * sizeof(float));
    #pragma omp parallel for
    for(size_t si = 0; si < M; si += BLOCKSIZE) {
        for(size_t sj = 0; sj < N; sj += BLOCKSIZE) {
            for(size_t sk = 0; sk < K; sk += BLOCKSIZE) {
                do_block_avx2_bt_f32f32f32(M, K, N, si, sk, sj, A, B, C);
            }
        }
    }
}
