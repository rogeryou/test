// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <iostream>
#include <math.h>
#include <immintrin.h>
#include <cstring>

#include "fortix.h"
#include "fortix_private.h"
#include "cpu/matmul.h"
#include "cpu/quant.h"

void convert_fp16_to_fp32_avx512(const float16 *src, float *dst, size_t count) {
    size_t i = 0;
    for (; i + 7 < count; i += 8) {
        __m128i fp16_data = _mm_loadu_si128((__m128i*)&src[i]);
        __m256 fp32_data = _mm256_cvtph_ps(fp16_data);
        _mm256_storeu_ps(&dst[i], fp32_data);
    }
    // 处理剩余部分
    for (; i < count; i++) {
        dst[i] = FP16ToFP32(src[i]);
    }
}

void convert_fp32_to_fp16_avx512(const float *src, float16 *dst, size_t count) {
    size_t i = 0;
    for (; i + 7 < count; i += 8) {
        __m256 fp32_data = _mm256_loadu_ps(src + i);
        __m128i fp16_data = _mm256_cvtps_ph(fp32_data, _MM_FROUND_TO_NEAREST_INT);
        _mm_storeu_si128((__m128i*)(dst + i), fp16_data);
    }
    // 处理剩余部分
    for (; i < count; i++) {
        dst[i] = FP32ToFP16(src[i]);
    }
}


void convert_int8_to_fp32_avx2(const int8_t* src, float* dst, size_t n) {
    size_t i = 0;

    // 批量转换每 8 个 INT8 元素（256 位）
    for (; i + 31 < n; i += 32) {
        __m256i a_i8 = _mm256_loadu_si256((const __m256i*)(src + i)); // 32 x int8_t

        // Split into two 128-bit chunks, sign-extend to 16-bit
        __m128i low_i8  = _mm256_extracti128_si256(a_i8, 0); // lower 128 bits
        __m128i high_i8 = _mm256_extracti128_si256(a_i8, 1); // upper 128 bits

        __m256i a_i16_lo = _mm256_cvtepi8_epi16(low_i8);  // 16 x int16_t -> lower 16
        __m256i a_i16_hi = _mm256_cvtepi8_epi16(high_i8); // 16 x int16_t -> upper 16

        // Convert to float
        __m256 a_f32_lo = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_lo, 0)));
        __m256 a_f32_lo2 = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_lo, 1)));
        __m256 a_f32_hi = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_hi, 0)));
        __m256 a_f32_hi2 = _mm256_cvtepi32_ps(_mm256_cvtepi16_epi32(_mm256_extracti128_si256(a_i16_hi, 1)));

        // 存储结果到目标数组
        _mm256_storeu_ps(&dst[i], a_f32_lo);
        _mm256_storeu_ps(&dst[i+8], a_f32_lo2);
        _mm256_storeu_ps(&dst[i+16], a_f32_hi);
        _mm256_storeu_ps(&dst[i+24], a_f32_hi2);
    }

    // 处理剩余的部分（如果有）
    for (; i < n; i++) {
        dst[i] = (float)src[i];  // 简单的标量转换
    }
}

// void convert_int8_to_fp16_avx2(const int8_t* src, float16* dst, size_t n) {
//     size_t i = 0;

//     // 批量转换每 8 个 INT8 元素（256 位）
//     for (; i + 31 < n; i += 32) {
//         __m256i a_i8 = _mm256_loadu_si256((const __m256i*)(src + i)); // 32 x int8_t

//         // Split into two 128-bit chunks, sign-extend to 16-bit
//         __m128i low_i8  = _mm256_extracti128_si256(a_i8, 0); // lower 128 bits
//         __m128i high_i8 = _mm256_extracti128_si256(a_i8, 1); // upper 128 bits

//         __m256i a_f16_lo = _mm256_cvtepi8_epi16(low_i8);  // 16 x fp16_t -> lower 16
//         __m256i a_f16_hi = _mm256_cvtepi8_epi16(high_i8); // 16 x fp16_t -> upper 16

//         // 存储结果到目标数组
//         _mm256_storeu_ps(&dst[i], a_f16_lo);
//         _mm256_storeu_ps(&dst[i+16], a_f16_hi);
//     }

//     // 处理剩余的部分（如果有）
//     for (; i < n; i++) {
//         dst[i] = (float16)src[i];  // 简单的标量转换
//     }
// }

ftxStatus ftxRMSNorm(ftxTensor *self, ftxTensor *gamma, float epsilon,
                     ftxTensor *out) {
    if (self->Get() == nullptr || gamma->Get() == nullptr ||
        out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *in_vec = static_cast<float *>(self->Get());
        float *g_vec = static_cast<float *>(gamma->Get());
        float *out_vec = static_cast<float *>(out->Get());
        size_t n = self->Size();
        size_t ndim = self->GetNDim();
        std::vector<int> shape = self->Shape();
        size_t elem_in_row = shape[ndim - 1];

        for (size_t i = 0; i < n; i += elem_in_row) {
            // calculate sum of squares
            float ss = 0.0f;
            #pragma omp parallel for reduction(+:ss)
            for (size_t j = i; j < i + elem_in_row; j++) {
                ss += in_vec[j] * in_vec[j];
            }

            ss = 1.0f / sqrtf(ss / elem_in_row + epsilon);

            // normalize and scale
            #pragma omp parallel for
            for (size_t j = i; j < i + elem_in_row; j++) {
                out_vec[j] = g_vec[j] * (ss * in_vec[j]);
            }
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSwiglu(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());
        if(other) {
            float *otherf = static_cast<float*>(other->Get());
            #pragma omp parallel for
            for(size_t i = 0; i < self->Size(); i++) {
                output[i] = (otherf[i] * input[i])/(1.0 + expf32(-input[i]));
            }
        } else {
            #pragma omp parallel for
            for(size_t i = 0; i < self->Size(); i++) {
                output[i] = input[i]/(1.0 + expf32(-input[i]));
            }
        }


    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSoftmax(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());
        float sum_up = 0.0;
        float max_value = input[0];

        #pragma omp parallel for reduction(max:max_value)
        for(size_t i = 1; i < self->Size(); i++) {
            if(input[i] > max_value){
                max_value = input[i];
            }
        }

        #pragma omp parallel for reduction(+:sum_up)
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = expf(input[i] - max_value);
            sum_up += output[i];
        }

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = output[i] / sum_up;
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxEmbedding(ftxTensor *weight, const int *indices, size_t n_indices, ftxTensor *out) {
    // keep rectify
    if (weight->Get() == nullptr || indices == nullptr
        || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (weight->Type() == FTX_FP32) {
        const float *input = static_cast<float*>(weight->Get());
        float *output = static_cast<float*>(out->Get());
        int embed_dim = weight->Shape()[1];

        for(size_t i = 0; i < n_indices; ++i) {
           int token_id = indices[i];
           for(int j = 0; j < embed_dim; ++j) {
                output[i * embed_dim + j] = input[token_id * embed_dim + j];
           }
        }
    } else if (weight->Type() == FTX_INT8 && out->Type() == FTX_INT8) {
        const int8_t *input = static_cast<int8_t*>(weight->Get());
        int8_t *output = static_cast<int8_t*>(out->Get());

        int embed_dim = weight->Shape()[1];

        for(size_t i = 0; i < n_indices; i++) {
           int token_id = indices[i];
           for(int j = 0; j < embed_dim; j++) {
                output[i * embed_dim + j] = input[token_id * embed_dim + j];
           }
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxCos(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *inputf = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = cosf(inputf[i]);
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxSin(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32) {
        float *inputf = static_cast<float*>(self->Get());
        float *output = static_cast<float*>(out->Get());

        #pragma omp parallel for
        for(size_t i = 0; i < self->Size(); i++) {
            output[i] = sinf(inputf[i]);
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxRope(ftxTensor *self, int pos, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    size_t ndim = self->GetNDim();
    int size = self->Shape()[ndim - 1];

    if (self->Type() == FTX_FP32) {
        float *input = static_cast<float *>(self->Get());
        float *output = static_cast<float *>(out->Get());

        int half_size = size / 2;
        #pragma omp parallel for
        for (int i = 0; i < size; i += 2) {
            int index = i / 2;
            float theta = pow(10000.0, -(float)index / half_size);
            float angle = pos * theta;

            float cos_theta = cosf(angle);
            float sin_theta = sinf(angle);

            float x0 = input[i];
            float x1 = input[i + 1];

            output[i]     = x0 * cos_theta - x1 * sin_theta;
            output[i + 1] = x0 * sin_theta + x1 * cos_theta;
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxAdd(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32 && other->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());

        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *selff = static_cast<float*>(self->Get());
        float *otherf = static_cast<float*>(other->Get());
        float *outf = static_cast<float*>(out->Get());

        if(BcastType == FTX_BROADCAST_NONE) {
            for (size_t i = 0; i < self->Size(); i++) {
                outf[i] = selff[i] + otherf[i];
            }
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            printf("NSDIM\n");
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[j] + otherf[i * vlen + j];
                    }
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();
                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[i * vlen + j] + otherf[j];
                    }
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape(),
                                                    out->GetElemBits());
            vector<int> stride_A = ComputeStrides(self->Shape(),
                                                  self->GetElemBits());
            vector<int> stride_B = ComputeStrides(other->Shape(),
                                                  other->GetElemBits());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            // Compute bcast elementwise add
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] +
                          otherf[index_B / elem_bytes_B];
            }
            return FTX_OK;
        }
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxSub(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32 && other->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());

        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *selff = static_cast<float*>(self->Get());
        float *otherf = static_cast<float*>(other->Get());
        float *outf = static_cast<float*>(out->Get());

        if(BcastType == FTX_BROADCAST_NONE) {
            for (size_t i = 0; i < self->Size(); i++) {
                outf[i] = selff[i] - otherf[i];
            }
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[j] - otherf[i * vlen + j];
                    }
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();
                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[i * vlen + j] - otherf[j];
                    }
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape(),
                                                    out->GetElemBits());
            vector<int> stride_A = ComputeStrides(self->Shape(),
                                                  self->GetElemBits());
            vector<int> stride_B = ComputeStrides(other->Shape(),
                                                  other->GetElemBits());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            // Compute bcast elementwise add
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] -
                          otherf[index_B / elem_bytes_B];
            }
            return FTX_OK;
        }
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxMul(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (out->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());

        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *outf = static_cast<float*>(out->Get());

        float *self_m = (float *)malloc(self->Size() * sizeof(float));
        float *other_m = (float *)malloc(other->Size() * sizeof(float));
        float *selff = self_m;
        float *otherf = other_m;


        switch (self->Type()) {
            case FTX_FP32:
            {
                selff = static_cast<float*>(self->Get());
                break;
            }
            case FTX_FP16:
            {
                float16 *selff16 = static_cast<float16*>(self->Get());
                // need rectify to ftxAlloc
                convert_fp16_to_fp32_avx512(selff16, selff, self->Size());
                break;
            }
            case FTX_INT8:
            {
                int8_t *selfint8 = static_cast<int8_t*>(self->Get());
                // need rectify to ftxAlloc
                convert_int8_to_fp32_avx2(selfint8, selff, self->Size());
                break;
            }
            default:
            {
                free(self_m);
                free(other_m);
                return FTX_INVALID_SHAPE;
            }
        }
        switch (other->Type()) {
            case FTX_FP32:
            {
                otherf = static_cast<float*>(other->Get());
                break;
            }
            case FTX_FP16:
            {
                float16 *otherf16 = static_cast<float16*>(other->Get());
                // need rectify to ftxAlloc
                convert_fp16_to_fp32_avx512(otherf16, otherf, other->Size());
                break;
            }
            case FTX_INT8:
            {
                int8_t *otherint8 = static_cast<int8_t*>(other->Get());
                // need rectify to ftxAlloc
                convert_int8_to_fp32_avx2(otherint8, otherf, other->Size());
                break;
            }
            default:
            {
                free(self_m);
                free(other_m);
                return FTX_INVALID_SHAPE;
            }
        }

        if(BcastType == FTX_BROADCAST_NONE) {
            for (size_t i = 0; i < self->Size(); i++) {
                outf[i] = selff[i] * otherf[i];
            }
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[j] * otherf[i * vlen + j];
                    }
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();
                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[i * vlen + j] * otherf[j];
                    }
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape(),
                                                    out->GetElemBits());
            vector<int> stride_A = ComputeStrides(self->Shape(),
                                                  self->GetElemBits());
            vector<int> stride_B = ComputeStrides(other->Shape(),
                                                other->GetElemBits());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            // Compute bcast elementwise add
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] *
                          otherf[index_B / elem_bytes_B];
            }
        }
        free(self_m);
        free(other_m);
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxDiv(ftxTensor *self, ftxTensor *other, ftxTensor *out) {
    if (self->Get() == nullptr || other->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->Type() == FTX_FP32 && other->Type() == FTX_FP32) {
        ftxBroadcast BcastType = BroadcastType(self->Shape(), other->Shape());

        if (BcastType == FTX_BROADCAST_INVALID) {
            return FTX_INVALID_SHAPE; // shapes are invalid for element-wise calculation
        }

        float *selff = static_cast<float*>(self->Get());
        float *otherf = static_cast<float*>(other->Get());
        float *outf = static_cast<float*>(out->Get());

        if(BcastType == FTX_BROADCAST_NONE) {
            for (size_t i = 0; i < self->Size(); i++) {
                outf[i] = selff[i] / otherf[i];
            }
        } else if(BcastType == FTX_BROADCAST_NSDIM) {
            size_t dims_A = self->Shape().size();
            size_t dims_B = other->Shape().size();
            if (dims_A < dims_B) {
                // A broadcast to B
                size_t loop = other->Size() / self->Size();
                size_t vlen = self->Size();

                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[j] / otherf[i * vlen + j];
                    }
                }
            } else {
                // B broadcast to A
                size_t loop = self->Size() / other->Size();
                size_t vlen = other->Size();
                for(size_t i = 0; i < loop; i++){
                    for(size_t j = 0; j < vlen; j++) {
                        outf[i * vlen + j] = selff[i * vlen + j] / otherf[j];
                    }
                }
            }
        } else {
            // A B broadcast each other
            // calculate stride
            vector<int> stride_out = ComputeStrides(out->Shape(),
                                                    out->GetElemBits());
            vector<int> stride_A = ComputeStrides(self->Shape(),
                                                  self->GetElemBits());
            vector<int> stride_B = ComputeStrides(other->Shape(),
                                                  other->GetElemBits());

            // calculate bcast stride
            stride_A = BroadcastStride(self, stride_A, out);
            stride_B = BroadcastStride(other, stride_B, out);

            int elem_bytes_out = static_cast<int>(out->GetElemBits()) / 8;
            int elem_bytes_A = static_cast<int>(self->GetElemBits()) / 8;
            int elem_bytes_B = static_cast<int>(other->GetElemBits()) / 8;
            // Compute bcast elementwise add
            for(size_t i = 0; i < out->Size(); i++) {
                int val = i;
                int index_A = 0;
                int index_B = 0;
                int coo = 0;
                for(size_t j = 0; j < stride_out.size(); j++) {
                    coo = val / (stride_out[j] / elem_bytes_out);
                    if(stride_A[j] != 0) {
                        index_A += coo * stride_A[j];
                    }

                    if(stride_B[j] != 0) {
                        index_B += coo * stride_B[j];
                    }
                    val = val % (stride_out[j] / elem_bytes_out);
                }
                outf[i] = selff[index_A / elem_bytes_A] /
                          otherf[index_B / elem_bytes_B];
            }
            return FTX_OK;
        }
        return FTX_OK;
    } else {
        return FTX_INVALID_TYPE;
    }
}

ftxStatus ftxMatmul(ftxContext *ctx, ftxTensor *inp, ftxTensor *wgt, bool wgt_transposed,
                    int32_t *bias, int deqScale, ftxTensor *out) {
    if (inp->Get() == nullptr || wgt->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    vector<int> shape_inp = inp->Shape();
    vector<int> shape_wgt = wgt->Shape();
    vector<int> shape_out = out->Shape();
    size_t m, k, n;

    if (shape_inp.size() != 2 || shape_wgt.size() != 2 || shape_out.size() != 2) {
        return FTX_INVALID_SHAPE;
    }

    if(wgt_transposed) {
        if (shape_inp[1] != shape_wgt[1] || shape_inp[0] != shape_out[0] || shape_wgt[0] != shape_out[1]) {
            return FTX_INVALID_SHAPE;
        }
    } else {
        if (shape_inp[1] != shape_wgt[0] || shape_inp[0] != shape_out[0] || shape_wgt[1] != shape_out[1]) {
            return FTX_INVALID_SHAPE;
        }
    }

    m = shape_inp[0];
    k = shape_inp[1];
    n = shape_out[1];
    if (inp->Type() == FTX_INT8 && wgt->Type() == FTX_INT8 && out->Type() == FTX_FP32) {
        if (wgt_transposed) {
            matmul_bt_i8i8f32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (float *)out->Get());
        } else {
            matmul_i8i8f32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (float *)out->Get());
        }
    } else if (inp->Type() == FTX_INT8 && wgt->Type() == FTX_INT8 && out->Type() == FTX_INT32) {
        if (wgt_transposed) {
            matmul_bt_i8i8i32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (int32_t *)out->Get());
        } else {
            matmul_i8i8i32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (int32_t *)out->Get());
        }
    } else if (inp->Type() == FTX_INT8 && wgt->Type() == FTX_FP32 && out->Type() == FTX_FP32) {
        if (wgt_transposed) {
            matmul_bt_i8f32f32(m, k, n, (int8_t *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        } else {
            matmul_i8f32f32(m, k, n, (int8_t *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        }
    } else if (inp->Type() == FTX_FP16 && wgt->Type() == FTX_FP32 && out->Type() == FTX_FP32) {
         if (wgt_transposed) {
            matmul_bt_f16f32f32(m, k, n, (float16 *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        } else {
            matmul_f16f32f32(m, k, n, (float16 *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        }
    } else if (inp->Type() == FTX_FP32 && wgt->Type() == FTX_FP16 && out->Type() == FTX_FP32) {
         if (wgt_transposed) {
            matmul_bt_f32f16f32(m, k, n, (float *)inp->Get(), (float16 *)wgt->Get(), (float *)out->Get());
        } else {
            matmul_f32f16f32(m, k, n, (float *)inp->Get(), (float16 *)wgt->Get(), (float *)out->Get());
        }
    } else if (inp->Type() == FTX_FP32 && wgt->Type() == FTX_FP32 && out->Type() == FTX_FP32) {
         if (wgt_transposed) {
            matmul_bt_f32f32f32(m, k, n, (float *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        } else {
            matmul_f32f32f32(m, k, n, (float *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        }
    } else {
        return FTX_INVALID_TYPE;
    }

    ctx->calcGEMMStats(m, k, n);

    return FTX_OK;
}

struct timespec diff(struct timespec start, struct timespec end) {
    struct timespec temp;
    if ((end.tv_nsec-start.tv_nsec)<0) {
        temp.tv_sec = end.tv_sec-start.tv_sec-1;
        temp.tv_nsec = 1000000000+end.tv_nsec-start.tv_nsec;
    } else {
        temp.tv_sec = end.tv_sec-start.tv_sec;
        temp.tv_nsec = end.tv_nsec-start.tv_nsec;
    }
    return temp;
}

ftxStatus ftxQuantMatmul(ftxTensor *inp_q, ftxTensor *inp_s, ftxTensor *wgt_q, ftxTensor *wgt_s, bool wgt_transposed,
                     const int block_size, ftxTensor *out) {
    if (inp_q->Get() == nullptr || wgt_q->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    vector<int> shape_inp = inp_q->Shape();
    vector<int> shape_wgt = wgt_q->Shape();
    vector<int> shape_out = out->Shape();
    size_t m, k, n;

    if (shape_inp.size() != 2 || shape_wgt.size() != 2 || shape_out.size() != 2) {
        return FTX_INVALID_SHAPE;
    }

    if(wgt_transposed) {
        if (shape_inp[1] != shape_wgt[1] || shape_inp[0] != shape_out[0] || shape_wgt[0] != shape_out[1]) {
            return FTX_INVALID_SHAPE;
        }
    } else {
        if (shape_inp[1] != shape_wgt[0] || shape_inp[0] != shape_out[0] || shape_wgt[1] != shape_out[1]) {
            return FTX_INVALID_SHAPE;
        }
    }
    m = shape_inp[0];
    k = shape_inp[1];
    n = shape_out[1];

    if (inp_q->Type() == FTX_INT8 && wgt_q->Type() == FTX_INT8 && out->Type() == FTX_FP32) {
        // if (wgt_transposed) {
        //     matmul_bt_i8i8f32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (float *)out->Get());
        // } else {
        //     matmul_i8i8f32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (float *)out->Get());
        // }
        return FTX_INVALID_TYPE;
    } else if (inp_q->Type() == FTX_INT8 && wgt_q->Type() == FTX_INT8 && out->Type() == FTX_INT32) {
        // if (wgt_transposed) {
            // matmul_bt_i8i8i32(m, k, n, (int8_t *)inp_q->Get(), (int8_t *)wgt_q->Get(), (int32_t *)out->Get());
        // } else {
            // matmul_i8i8i32(m, k, n, (int8_t *)inp->Get(), (int8_t *)wgt->Get(), (int32_t *)out->Get());
        // }
        return FTX_INVALID_TYPE;
    } else if (inp_q->Type() == FTX_FP32 && wgt_q->Type() == FTX_INT8 && out->Type() == FTX_FP32) {

        if (wgt_transposed) {
            // fp32 data should not have scale.
            if(inp_s != NULL) return FTX_INVALID_INPUT;
            // quant fp32 data to q8
            std::vector<int> q8_dims = inp_q->Shape();
            // alocate space for q8 data
            size_t b = ComputeSize(q8_dims);
            int8_t *arr1 = new int8_t[b];
            ftxTensor *q8_inp = ftxCreateTensor(q8_dims.data(), nullptr, q8_dims.size(), FTX_INT8, inp_q->Layout(), arr1);

            vector<int> scale_dims = inp_q->Shape();

            scale_dims.back() = (scale_dims.back() + block_size -1) / block_size;

            // alocate space for scale
            size_t o = ComputeSize(scale_dims);
            float *arr_s = new float[o];
            inp_s = ftxCreateTensor(scale_dims.data(), nullptr, scale_dims.size(), FTX_FP32, inp_q->Layout(), arr_s);
            inp_s = ftxCreateTensor(scale_dims.data(), nullptr, scale_dims.size(), FTX_FP32, inp_q->Layout(), arr_s);

            f32_quant_q8(inp_q, block_size, q8_inp, inp_s);

            // ftxDumpTensor(inp_q);
            // ftxDumpTensor(q8_inp);
            // ftxDumpTensor(inp_s);

            matmul_bt_q8q8f32(m, k, n, (int8_t *)q8_inp->Get(), (float *)inp_s->Get(), (int8_t *)wgt_q->Get(), (float *)wgt_s->Get(), (float *)out->Get(), block_size);
            // ftxDumpTensor(out);
            ftxDestroyTensor(q8_inp);
            delete[] arr1;
            delete[] arr_s;

        } else {
            printf("weight should be transposed\n");
            return FTX_INVALID_TYPE;
            // matmul_i8f32f32(m, k, n, (int8_t *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        }
    } else if (inp_q->Type() == FTX_FP16 && wgt_q->Type() == FTX_FP32 && out->Type() == FTX_FP32) {
        //  if (wgt_transposed) {
        //     matmul_bt_f16f32f32(m, k, n, (float16 *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        // } else {
        //     matmul_f16f32f32(m, k, n, (float16 *)inp->Get(), (float *)wgt->Get(), (float *)out->Get());
        // }
        return FTX_INVALID_TYPE;
    } else {
        return FTX_INVALID_TYPE;
    }

    return FTX_OK;
}

ftxStatus ftxCpy(ftxTensor *self, ftxTensor *out) {
    if (self->Get() == nullptr || out->Get() == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    if (self->IsContiguous() && out->IsContiguous()) {
        if (self->Type() == FTX_FP32) {
            float *in_vec = static_cast<float *>(self->Get());
            if(out->Type() == FTX_FP32) {
                float *out_vec = static_cast<float *>(out->Get());
                memcpy(out_vec, in_vec, out->Size() * out->GetElemBits() / 8);
            } else if (out->Type() == FTX_FP16) {
                float16 *out_vec = static_cast<float16 *>(out->Get());
                convert_fp32_to_fp16_avx512(in_vec, out_vec, self->Size());
            } else {
                return FTX_INVALID_TYPE;
            }
        } else if (self->Type() == FTX_FP16) {
            float16 *in_vec = static_cast<float16 *>(self->Get());
            if(out->Type() == FTX_FP32) {
                float *out_vec = static_cast<float *>(out->Get());
                convert_fp16_to_fp32_avx512(in_vec, out_vec, self->Size());
            } else {
                return FTX_INVALID_TYPE;
            }
        } else if (self->Type() == FTX_INT8) {
            int8_t *in_vec = static_cast<int8_t *>(self->Get());
            if(out->Type() == FTX_FP32) {
                float *out_vec = static_cast<float *>(out->Get());
                convert_int8_to_fp32_avx2(in_vec, out_vec, self->Size());
            // follow up for debugging
            // } else if(out -> Type() == FTX_FP16) {
            //     ftx_fp16_t *out_vec = static_cast<ftx_fp16_t *>(out->Get());
            //     convert_int8_to_fp16_avx2(in_vec, out_vec, self->Size);
            } else if (out->Type() == FTX_INT8) {
                int8_t *out_vec = static_cast<int8_t *>(out->Get());
                memcpy(out_vec, in_vec, out->Size() * out->GetElemBits() / 8);
            } else {
                return FTX_INVALID_TYPE;
            }
        } else {
            return FTX_INVALID_TYPE;
        }
    } else {
        // #pragma omp parallel for
        for (uint32_t i = 0; i < self->Size(); i++) {
            // convert flat index to multi-dimensional index using new strides
            std::vector<int> index = OffsetToIndex(i, self->Shape());

            // convert multi-dimensional index to flat offset using old strides
            int in_offset = IndexToOffset(index, self->Strides(),
                                          self->GetElemBits());
            int out_offset = IndexToOffset(index, out->Strides(),
                                           out->GetElemBits());

            // copy data at old index to new index
            if (self->Type() == FTX_FP32) {
                float *in_ptr = static_cast<float *>(self->Get());
                if(out->Type() == FTX_FP32) {
                    float *out_ptr = static_cast<float *>(out->Get());
                    out_ptr[out_offset] = in_ptr[in_offset];
                } else if (out->Type() == FTX_FP16) {
                    float16 *out_ptr = static_cast<float16 *>(out->Get());
                    out_ptr[out_offset] = FP32ToFP16(in_ptr[in_offset]);
                } else {
                    return FTX_INVALID_TYPE;
                }
            } else if (self->Type() == FTX_FP16) {
                float16 *in_ptr = static_cast<float16 *>(self->Get());
                if(out->Type() == FTX_FP32) {
                    float *out_ptr = static_cast<float *>(out->Get());
                    out_ptr[out_offset] = FP16ToFP32(in_ptr[in_offset]);
                } else {
                    return FTX_INVALID_TYPE;
                }
            } else if (self->Type() == FTX_INT8) {
                int8_t *in_ptr = static_cast<int8_t *>(self->Get());
                if(out->Type() == FTX_FP32) {
                    float *out_ptr= static_cast<float *>(out->Get());
                    out_ptr[out_offset] = static_cast<float>(in_ptr[in_offset]);
                // follow up for debugging
                // } else if(out -> Type() == FTX_FP16) {
                //     ftx_fp16_t *out_vec = static_cast<ftx_fp16_t *>(out->Get());
                //     convert_int8_to_fp16_avx2(in_vec, out_vec, self->Size);
                } else if (out->Type() == FTX_INT8) {
                    int8_t *out_ptr = static_cast<int8_t *>(out->Get());
                    out_ptr[out_offset] = in_ptr[in_offset];
                } else {
                    return FTX_INVALID_TYPE;
                }
            } else {
                return FTX_INVALID_TYPE;
            }
        }
    }
    return FTX_OK;
}
