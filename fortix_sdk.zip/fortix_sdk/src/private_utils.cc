// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <string>
#include <vector>

#include "fortix.h"
#include "fortix_private.h"

const string FTX_1D_STR   = "FTX_1D";
const string FTX_2D_STR   = "FTX_2D";
const string FTX_3D_STR   = "FTX_3D";
const string FTX_3DS_STR  = "FTX_3DS";
const string FTX_4D_STR   = "FTX_4D";
const string FTX_NHWC_STR = "FTX_NHWC";
const string FTX_NCHW_STR = "FTX_NCHW";
const string FTX_HWCK_STR = "FTX_HWCK";

const string FTX_FORMAT_4DFEATURE_STR = "FTX_FORMAT_4DFEATURE";
const string FTX_FORMAT_4DKERNEL_STR  = "FTX_FORMAT_4DKERNEL";
const string FTX_FORMAT_4DWEIGHTS_STR = "FTX_FORMAT_4DWEIGHTS";
const string FTX_FORMAT_4DGENERIC_STR = "FTX_FORMAT_4DGENERIC";

const string INT4_STR   = "INT4";
const string INT8_STR   = "INT8";
const string INT32_STR  = "INT32";
const string BFLOAT_STR = "BFLOAT";
const string FP16_STR   = "FP16";
const string FP32_STR   = "FP32";

const string NULL_STR   = "NULL";

short GetDataLayoutDims(ftxDataLayout layout) {

#define CASE_RTN_DIM(a, b)                                                     \
    case a:                                                                    \
        return b;

    switch (layout) {
        CASE_RTN_DIM(FTX_1D, 1);
        CASE_RTN_DIM(FTX_2D, 2);
        CASE_RTN_DIM(FTX_3D, 3);
        CASE_RTN_DIM(FTX_3DS, 3);
        CASE_RTN_DIM(FTX_4D, 4);
        CASE_RTN_DIM(FTX_NHWC, 4);
        CASE_RTN_DIM(FTX_NCHW, 4);
        CASE_RTN_DIM(FTX_HWCK, 4);
    default:
        LOG_WARN << "Unknown layout: " << layout << LOG_ENDL;
        return 0;
    }
#undef CASE_RTN_DIM
}

const string& GetDataLayoutStr(ftxDataLayout layout) {
    switch (layout) {
    case FTX_1D:
        return FTX_1D_STR;
    case FTX_2D:
        return FTX_2D_STR;
    case FTX_3D:
        return FTX_3D_STR;
    case FTX_3DS:
        return FTX_3DS_STR;
    case FTX_4D:
        return FTX_4D_STR;
    case FTX_NHWC:
        return FTX_NHWC_STR;
    case FTX_NCHW:
        return FTX_NCHW_STR;
    case FTX_HWCK:
        return FTX_HWCK_STR;
    default:
        return NULL_STR;
    }
}

uint32_t GetDataTypeBits(ftxDataType type) {
    switch (type) {
    case FTX_INT4:
        return 4;
    case FTX_INT8:
        return 8;
    case FTX_INT32:
        return 32;
    case FTX_BFLOAT:
        return 16;
    case FTX_FP16:
        return 16;
    case FTX_FP32:
        return 32;
    default:
        return 0;
    }
}

const string& GetDataTypeStr(ftxDataType type) {
    switch (type) {
    case FTX_INT4:
        return INT4_STR;
    case FTX_INT8:
        return INT8_STR;
    case FTX_INT32:
        return INT32_STR;
    case FTX_BFLOAT:
        return BFLOAT_STR;
    case FTX_FP16:
        return FP16_STR;
    case FTX_FP32:
        return FP32_STR;
    default:
        return NULL_STR;
    }
}

int8_t Int32ToInt8(int32_t in_data) {
    return static_cast<int8_t>(in_data);
}

int8_t FP32ToInt8(float in_data) {
    return static_cast<int8_t>(in_data);
}

float Int8ToFP32(int8_t in_data) {
    return static_cast<float>(in_data);
}

int32_t Int8ToInt32(int8_t in_data) {
    return static_cast<int32_t>(in_data);
}

size_t ComputeSize(const std::vector<int>& dim) {
    size_t size = 1;
    for (uint32_t i = 0; i < dim.size(); i++) {
        size *= dim[i];
    }

    return size;
}

std::vector<int> ComputeStrides(const std::vector<int> &shape,
                                size_t elem_bits) {
    int ndim = shape.size();
    std::vector<int> strides(ndim);
    strides[ndim - 1] = 1 * elem_bits / 8;
    for (int i = ndim - 2; i >= 0; i--) {
        strides[i] = strides[i + 1] * shape[i + 1];
    }

    return strides;
}

int IndexToOffset(const std::vector<int> &index,
                  const std::vector<int> &strides, size_t elem_bits) {
    int ndim = strides.size(), offset = 0;
    for (int i = 0; i < ndim; i++) {
        offset += index[i] * strides[i];
    }
    return offset / (elem_bits / 8);
}

std::vector<int> OffsetToIndex(int offset, const std::vector<int> &shape) {
    int ndim = shape.size();
    std::vector<int> index(ndim);
    for (int d = ndim - 1; d >= 0; d--) {
        index[d] = offset % shape[d];
        offset = offset / shape[d];
    }

    return index;
}

ftxBroadcast BroadcastType(const vector<int> A, const vector<int> B) {
    int dims_A = static_cast<int>(A.size());
    int dims_B = static_cast<int>(B.size());

    if(dims_A == dims_B) {
        int flag = 0;
        for(int i = 0; i < dims_A; i++) {
            if(A[i] != B[i]) {
                if(A[i] != 1 && B[i] != 1) {
                    return FTX_BROADCAST_INVALID;
                }
                else {
                    flag = 1;
                }
            }
        }
        if (flag == 0){
            return FTX_BROADCAST_NONE;
        }

        return FTX_BROADCAST_OTHER;
    }
    else {
        int small_dims = (dims_A < dims_B ) ? dims_A : dims_B;
        int flag = 0;
        for(int i = 0; i < small_dims; i++) {
            if(A[dims_A -1 - i] != B[dims_B -1 - i]) {
                if((A[dims_A -1 - i] != 1) && (B[dims_B -1 - i] != 1)) {
                    return FTX_BROADCAST_INVALID;
                } else {
                    flag = 1;
                }
            }
        }
        if(flag == 1){
           return FTX_BROADCAST_OTHER;
        }

        return FTX_BROADCAST_NSDIM;
    }
}

vector<int> BroadcastOutShape(const vector<int> A, const vector<int> B){
    ftxBroadcast type = BroadcastType(A, B);
    vector<int> out = A;
    if(type == FTX_BROADCAST_INVALID){
        printf("invalid broadcast type!!!!!\n");
        return {};
    } else if (type == FTX_BROADCAST_NONE) {
        return out;
    } else if (type == FTX_BROADCAST_OTHER) {
        auto dims_A = static_cast<int>(A.size());
        auto dims_B = static_cast<int>(B.size());
        if(dims_A > dims_B) {
            for(int i = 0; i < dims_B; i++) {
                int k = dims_A - dims_B + i;
                if(A[k] == 1) {
                    out[k] = B[i];
                }
            }
        } else {
            out = B;
            for(int i = 0; i < dims_A; i++) {
                int k = dims_B - dims_A + i;
                if(B[k] == 1) {
                    out[k] = A[i];
                }
            }
        }
        return out;
    } else {
        auto dims_A = static_cast<int>(A.size());
        auto dims_B = static_cast<int>(B.size());
        if(dims_A < dims_B) {
            out = B;
        }
        return out;
    }
}

vector<int> BroadcastStride(ftxTensor *self, vector<int> stride, ftxTensor *bcast_result) {
    // we only calculate the numbers of elements
    // In numpy they will caclulate the number of bytes
    size_t out_dims = bcast_result->Shape().size();
    vector<int> stride_bcast(out_dims, 0);

    for(size_t i = 0; i < out_dims; i++) {
        int k = self->Shape().size() - out_dims + i;
        if(k < 0) {
            stride_bcast[i] = 0;
        } else if(self->Shape()[k] != bcast_result->Shape()[i]) {
                stride_bcast[i] = 0;
        } else {
            stride_bcast[i] = stride[k];
        }
    }
    return stride_bcast;
}

static uint32_t as_uint(const float x) {
    return *(uint32_t*)&x;
}

static float as_float(const uint32_t x) {
    return *(float*)&x;
}

float FP16ToFP32(float16 x) { // IEEE-754 16-bit floating-point format (without infinity): 1-5-10, exp-15, +-131008.0, +-6.1035156E-5, +-5.9604645E-8, 3.311 digits
    const uint32_t e = (x & 0x7C00) >> 10; // exponent
    const uint32_t m = (x & 0x03FF) << 13; // mantissa
    const uint32_t v = as_uint((float)m) >> 23; // evil log2 bit hack to count leading zeros in denormalized format
    uint32_t result = (x & 0x8000) << 16 |
                      (e != 0) * ((e + 112) << 23 | m) |
                      ((e == 0) & (m != 0)) *
                      ((v - 37) << 23 | ((m << (150 - v)) & 0x007FE000));
                      // sign : normalized : denormalized
    return as_float(result);
}

float16 FP32ToFP16(float x) { // IEEE-754 16-bit floating-point format (without infinity): 1-5-10, exp-15, +-131008.0, +-6.1035156E-5, +-5.9604645E-8, 3.311 digits
    const uint32_t b = as_uint(x) + 0x00001000; // round-to-nearest-even: add last bit after truncated mantissa
    const uint32_t e = (b & 0x7F800000) >> 23; // exponent
    const uint32_t m = b & 0x007FFFFF; // mantissa; in line below: 0x007FF000 = 0x00800000-0x00001000 = decimal indicator flag - initial rounding
    float16 result = (b & 0x80000000)>>16 |
                     (e > 112) * ((((e - 112) << 10) & 0x7C00) | m >> 13) |
                     ((e < 113)&(e > 101)) *
                     ((((0x007FF000 + m) >> (125 - e)) + 1) >> 1) |
                     (e > 143) * 0x7FFF;
                     // sign : normalized : denormalized : saturate
    return result;
}
