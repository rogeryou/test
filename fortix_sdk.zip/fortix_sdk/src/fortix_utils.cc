// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

//#include <memory>
#include <cstdlib>
#include <cstring>
#include <cassert>

#include "fortix.h"
#include "fortix_private.h"
#include "vmem/virtual_memory.h"

using namespace ftx::vmem;

ftxTensor *ftxCreateTensor(const int32_t *shape, const int32_t *strides,
                           size_t ndim, ftxDataType type,
                           ftxDataLayout layout, void *data) {

    return new ftxTensor(shape, strides, ndim, type, layout, data);
}

ftxStatus ftxDestroyTensor(ftxTensor *self) {
    delete self;
    return FTX_OK;
}

ftxStatus ftxGetSize(const ftxTensor *self, size_t *size) {
    if (self == nullptr || size == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    *size = self->Size();

    return FTX_OK;
}

ftxStatus ftxGetBufferSize(const ftxTensor *self, size_t *buffer_size) {
    if (self == nullptr || buffer_size == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    *buffer_size = self->BufferSize();

    return FTX_OK;
}

ftxStatus ftxGetShape(const ftxTensor *self, int32_t **shape, size_t *ndim) {
    if (self == nullptr || shape == nullptr || ndim == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    std::vector<int> ret_shape = self->Shape();
    *ndim = ret_shape.size();
    *shape = new int(*ndim);
    std::copy(ret_shape.begin(), ret_shape.end(), *shape);

    return FTX_OK;
}

ftxStatus ftxGetStrides(const ftxTensor *self, int32_t **strides, size_t *ndim) {
    if (self == nullptr || strides == nullptr || ndim == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    std::vector<int> ret_strides = self->Strides();
    *ndim = ret_strides.size();
    *strides = new int(*ndim);
    std::copy(ret_strides.begin(), ret_strides.end(), *strides);

    return FTX_OK;
}

ftxStatus ftxGetLayout(const ftxTensor *self, ftxDataLayout *layout) {
    if (self == nullptr || layout == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    *layout = self->Layout();

    return FTX_OK;
}

ftxStatus ftxGetDataType(const ftxTensor *self, ftxDataType *type) {
    if (self == nullptr || type == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    *type = self->Type();

    return FTX_OK;
}

ftxStatus ftxGetPtr(ftxTensor *self, void **ptr) {
    if (self == nullptr || ptr == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    *ptr = self->Get();

    return FTX_OK;
}

bool ftxIsContiguous(const ftxTensor *self) {
    if (self == nullptr) {
        return false;
    }

    return self->IsContiguous();
}

ftxStatus ftxReshape(ftxTensor *self, const int *new_shape, size_t ndim, ftxTensor *out) {
    if (self == nullptr || new_shape == nullptr || ndim == 0) {
        return FTX_INVALID_INPUT;
    }

    std::vector<int> shape(ndim);
    for (uint32_t i = 0; i < ndim; i++) {
        shape[i] = new_shape[i];
    }

    self->Reshape(shape, out);

    return FTX_OK;
}

ftxStatus ftxTranspose(ftxTensor *self, const int *new_perm, size_t ndim) {
    if (self == nullptr || new_perm == nullptr || ndim == 0) {
        return FTX_INVALID_INPUT;
    }

    std::vector<int> perm(ndim);
    for (uint32_t i = 0; i < ndim; i++) {
        perm[i] = new_perm[i];
    }

    self->Transpose(perm);

    return FTX_OK;
}

ftxStatus ftxContiguous(ftxTensor *self, ftxTensor *out) {
    if (self == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    self->Contiguous(out);

    return FTX_OK;
}

ftxStatus ftxDumpTensor(const ftxTensor *self) {
    if (self == nullptr) {
        return FTX_INPUT_IS_NULL;
    }

    self->Dump();

    return FTX_OK;
}

ftxTensor *ftxBroadcastOutTensor(ftxTensor *in_tensor, ftxTensor *in_tensor1) {
    // return a ftxtensor with the data ptr is null, but has correct bcast shape tensor
    assert(in_tensor->Type() == in_tensor->Type());
    // (todo support more dtype)(check the datatype if FP32)
    assert(in_tensor->Type() == FTX_FP32);
    vector<int> A = in_tensor->Shape();
    vector<int> B = in_tensor1->Shape();
    ftxBroadcast type = BroadcastType(A, B);
    vector<int> out = A;
    if(type == FTX_BROADCAST_INVALID){
        printf("invalid broadcast type!!!!!\n");
        return NULL;
    } else if (type == FTX_BROADCAST_NONE) {
        float *arr = new float[ComputeSize(out)];
        return ftxCreateTensor(out.data(), nullptr, out.size(),
                               in_tensor->Type(), in_tensor->Layout(), arr);
    } else if (type == FTX_BROADCAST_OTHER) {
        auto dims_A = static_cast<int>(A.size());
        auto dims_B = static_cast<int>(B.size());
        ftxDataLayout layout = in_tensor->Layout();
        if(dims_A > dims_B) {
            for(int i = 0; i < dims_B; i++) {
                int k = dims_A - dims_B + i;
                if(A[k] == 1) {
                    out[k] = B[i];
                }
            }
        } else {
            layout = in_tensor1->Layout();
            out = B;
            for(int i = 0; i < dims_A; i++) {
                int k = dims_B - dims_A + i;
                if(B[k] == 1) {
                    out[k] = A[i];
                }
            }
        }
        float *arr = new float[ComputeSize(out)];
        return ftxCreateTensor(out.data(), nullptr, out.size(),
                               in_tensor->Type(), layout, arr);
    } else {
        auto dims_A = static_cast<int>(A.size());
        auto dims_B = static_cast<int>(B.size());
        ftxDataLayout layout = in_tensor->Layout();
        if(dims_A < dims_B) {
            layout = in_tensor1->Layout();
            out = B;
        }
        float *arr = new float[ComputeSize(out)];
        return ftxCreateTensor(out.data(), nullptr, out.size(),
                               in_tensor->Type(), layout, arr);
    }
}

void *ftxMalloc(size_t len) {
    VirtualMemoryManager *vmmgr = VirtualMemoryManager::Global();
    return vmmgr->Alloc(len);
}

void ftxFree(void *buf) {
    VirtualMemoryManager *vmmgr = VirtualMemoryManager::Global();
    return vmmgr->Free(buf);
}

void ftxMemcpy(void *dst, const void *src, size_t len, ftxMemCopyType type) {
    VirtualMemoryManager *vmmgr = VirtualMemoryManager::Global();
    ftx_phy_addr_t phy_addr;

    if (type == FTX_COPY_FROM_HOST) {
        phy_addr = vmmgr->GetPhyAddr(dst);
        vmmgr->MemCopyFromHost(phy_addr, src, len);
    } else {
        phy_addr = vmmgr->GetPhyAddr(const_cast<void *>(src));
        vmmgr->MemCopyToHost(dst, phy_addr, len);
    }
}

void ftxMemset(void *dst, int c, size_t len) {
    VirtualMemoryManager *vmmgr = VirtualMemoryManager::Global();
    ftx_phy_addr_t phy_addr = vmmgr->GetPhyAddr(dst);
    vmmgr->Memset(phy_addr, c, len);
}

void ftxGetMemInfo(size_t *free, size_t *total) {
    VirtualMemoryManager *vmmgr = VirtualMemoryManager::Global();
    vmmgr->GetMemInfo(free, total);
}

ftxContext *ftxCreateContext() {
    return new ftxContext();
}

ftxStatus ftxDestroyContext(ftxContext *self) {
    delete self;
    return FTX_OK;
}

ftxStatus ftxSetGEMMSize(ftxContext *self, uint32_t size) {
    return self->setGEMMSize(size);
}

void ftxShowStats(ftxContext *self) {
    self->showStats();
}

