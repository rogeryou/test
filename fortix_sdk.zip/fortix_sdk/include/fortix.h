// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FORTX_H_
#define FORTX_H_

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#ifdef __cplusplus
#include <vector>
#include <map>
#endif

#define FTX_VERSION "1.0.0"
#define FTX_VERNUM 0x010000 // 0x[major][minor][patch]
#define FTX_VER_MAJOR 1
#define FTX_VER_MINOR 0
#define FTX_VER_PATCH 0

#define FTX_WARNING 0x00020000
#define FTX_PARAMETER_ERROR 0x00040000
#define FTX_DATA_ERROR 0x00100000
#define FTX_HW_ERROR 0x000c0000

typedef enum {
    // ----------------------------------------------------------------
    FTX_OK = 0x00000000, // Success.
    FTX_INVALID_INPUT = FTX_PARAMETER_ERROR + 0x0001,
    FTX_INVALID_SHAPE,                                  // Invalid shape information in one (or more) of the input/output tensor(s).
    FTX_INVALID_LAYOUT,                                 // Invalid layout information in one (or more) of the input/output tensor(s).
    FTX_INVALID_TYPE,                                   // Invalid type information in one (or more) of the input/output tensor(s).
    FTX_INPUT_IS_NULL,                                  // Input parameter is NULL.
    // ----------------------------------------------------------------
    FTX_ALLOCATION_FAILURE = FTX_DATA_ERROR + 0x0001,   // Can not allocate storage.
    FTX_INVALID_BUFFER,                                 // Buffer address is NULL or not on 4K-byte boundary, or insufficient buffer size.
} ftxStatus;

typedef enum {
    FTX_INT4 = 250,
    FTX_INT8 = 251,                 // 8-bit signed or unsigned binary integer format
    FTX_INT32 = 252,                // 32-bit signed or unsigned binary integer format
    FTX_BFLOAT = 253,               // Brain floating point format
    FTX_FP16 = 254,                 // 16-bit IEEE-754 floating point format
    FTX_FP32 = 255,                 // 32-bit IEEE-754 floating point format
    FTX_ERROR_TYPE = 270
} ftxDataType;

typedef enum {
    FTX_1D,        // 1d tensor
    FTX_2D,        // 2d tensor
    FTX_3D,        // 3d tensor
    FTX_3DS,       // represents special 3D tensors required by
                    // LSTM/GRU/Softmax/Matmul
    FTX_4D,        // 4d tensor
    FTX_NHWC,      // 4d feature tensor in NHWC
    FTX_NCHW,      // 4d feature tensor in NCHW
    FTX_HWCK,      // 4d kernel CNN tensor
    FTX_OIHW,      // 4d kernel CNN tensor for dCIM
} ftxDataLayout;

typedef enum {
    FTX_BROADCAST_INVALID = 0, //Two tensors has invalid shapes, which cannot be calculate.               Ex: (3,4) + (3,2)
    FTX_BROADCAST_NONE,        // Two iuput tensors has same shape, no need to broadcast.                 Ex: (3,4) + (3,4)
    FTX_BROADCAST_NSDIM,       // Shapes of two tensors are different, but satisfying the broadcast rule. EX: (4,2) + (2) ==broadcast==> (4,2) + (1,2) ==broadcast==> (4,2) + (4,2)
    FTX_BROADCAST_OTHER,        // Others like: Ex: (3,1) + (1,3) ==broadcast==> (3,3)+(3,3) Ex2: (2,3,3) + (3,1) ==broadcast==> (2,3,3)+(2,3,3)
} ftxBroadcast;

typedef unsigned short float16;

typedef enum {
    FTX_COPY_FROM_HOST = 0,
    FTX_COPY_TO_HOST = 1
} ftxMemCopyType;

#ifdef __cplusplus
class ftxTensor {
public:
    ftxTensor() {}
    ftxTensor(const int *dims, const int *strides, size_t ndim, ftxDataType type,
              ftxDataLayout layout);
    ftxTensor(const int *dims, const int *strides, size_t ndim, ftxDataType type,
              ftxDataLayout layout, void *data);
    ~ftxTensor() {}

    size_t Size() const { return size_; }
    size_t BufferSize() const { return buffer_size_; }
    ftxDataLayout Layout() const { return layout_; }
    ftxDataType Type() const { return type_; }
    void *Get() { return buffer_; }
    std::vector<int> Shape() const { return shape_; }
    std::vector<int> Strides() const { return strides_; }
    size_t GetNDim() const { return ndim_; }
    size_t GetElemBits() const { return elem_bits_; }
    void Reshape(const std::vector<int> &new_shape, ftxTensor *out);
    void Transpose(const std::vector<int> &perm);
    void Dump() const;
    bool IsContiguous() const; // check whether the buffer is contiguous or not
    void Contiguous(ftxTensor *out);

private:
    bool IsPermValid(const std::vector<int> &perm);
    bool IsShapeValid(const std::vector<int> &new_shape);

private:
    std::vector<int> shape_; // shape of tensor
    std::vector<int> strides_; // strides of tensor
    size_t ndim_;
    size_t size_;
    size_t buffer_size_;               // tensor size in bytes
    size_t elem_bits_;                 // num of bits in an element
    ftxDataLayout layout_;
    ftxDataType type_;
    void *buffer_;                       // pointer to the tensor in memory
    float rec_scale_;    // the scale factor for quantization, stored as reciprocal
    float offset_;       // the offset for quantization
};

class ftxContext {
public:
    ftxContext();
    ~ftxContext() {}
    ftxStatus setGEMMSize(uint32_t size);
    void calcGEMMStats(size_t m, size_t k, size_t n);
    void showStats();
private:
    struct record {
        size_t m;
        size_t k;
        size_t n;
        size_t gemv_count;
        double estimated_time;
    };

    std::map<uint32_t, uint32_t> mac_time_map_;
    std::vector<record> stats_;
    // input bandwidth of 16 I/O LPDDR4 @ 800MHz = 3.2 GB/s
    float input_bw_ = 3200000000.0f;
    uint32_t tMAC_ = 1000;
    uint32_t gemm_size_;
    float one_mac_time_;
};
#else
typedef struct ftxTensor ftxTensor;
typedef struct ftxContext ftxContext;
#endif /* __cplusplus */

#ifdef __cplusplus
extern "C" {
#endif

void *ftxMalloc(size_t len);
void ftxFree(void *buf);
void ftxMemcpy(void *dst, const void *src, size_t len, ftxMemCopyType type);
void ftxMemset(void *dst, int c, size_t len);
void ftxGetMemInfo(size_t *free, size_t *total);

ftxContext *ftxCreateContext();
ftxStatus ftxDestroyContext(ftxContext *self);
ftxStatus ftxSetGEMMSize(ftxContext *self, uint32_t size);
void ftxShowStats(ftxContext *self);

ftxTensor *ftxCreateTensor(const int32_t *shape, const int32_t *strides,
                           size_t ndim, ftxDataType type,
                           ftxDataLayout layout, void *data);
ftxStatus ftxDestroyTensor(ftxTensor *self);

ftxStatus ftxGetSize(const ftxTensor *self, size_t *size);
ftxStatus ftxGetBufferSize(const ftxTensor *self, size_t *buffer_size);
ftxStatus ftxGetShape(const ftxTensor *self, int32_t **shape, size_t *ndim);
ftxStatus ftxGetStrides(const ftxTensor *self, int32_t **strides, size_t *ndim);
ftxStatus ftxGetLayout(const ftxTensor *self, ftxDataLayout *layout);
ftxStatus ftxGetDataType(const ftxTensor *self, ftxDataType *type);
ftxStatus ftxGetPtr(ftxTensor *self, void **ptr);

bool ftxIsContiguous(const ftxTensor *self);
ftxStatus ftxReshape(ftxTensor *self, const int *new_shape, size_t ndim, ftxTensor *out);
ftxStatus ftxTranspose(ftxTensor *self, const int *perm, size_t ndim);
ftxStatus ftxContiguous(ftxTensor *self, ftxTensor *out);

ftxStatus ftxDumpTensor(const ftxTensor *self);

// bcast
ftxTensor *ftxBroadcastOutTensor(ftxTensor *in_tensor, ftxTensor *in_tensor1);

// Normalization
ftxStatus ftxRMSNorm(ftxTensor *self, ftxTensor *gamma, float epsilon,
                     ftxTensor *out);

// Activation
ftxStatus ftxSwiglu(ftxTensor *self, ftxTensor *other, ftxTensor *out);
ftxStatus ftxSoftmax(ftxTensor *self, ftxTensor *out);

// Embedding
ftxStatus ftxEmbedding(ftxTensor *weight, const int *indices, size_t n_indices, ftxTensor *out);

// elemntwise based operator
ftxStatus ftxCos(ftxTensor *self, ftxTensor *out);
ftxStatus ftxSin(ftxTensor *self, ftxTensor *out);
ftxStatus ftxAdd(ftxTensor *self, ftxTensor *other, ftxTensor *out);
ftxStatus ftxSub(ftxTensor *self, ftxTensor *other, ftxTensor *out);
ftxStatus ftxMul(ftxTensor *self, ftxTensor *other, ftxTensor *out);
ftxStatus ftxDiv(ftxTensor *self, ftxTensor *other, ftxTensor *out);

// Rotray Position Embedding (RoPE)
ftxStatus ftxRope(ftxTensor *self, int pos, ftxTensor *out);

// Matmul/GEMM
ftxStatus ftxMatmul(ftxContext *ctx, ftxTensor *inp, ftxTensor *wgt,
                    bool wgt_transposed, int32_t *bias, int deqScale,
                    ftxTensor *out);
ftxStatus ftxQuantMatmul(ftxTensor *inp_q, ftxTensor *inp_s, ftxTensor *wgt_q, ftxTensor *wgt_s, bool wgt_transposed,
                     int block_size, ftxTensor *out);

// CPY
ftxStatus ftxCpy(ftxTensor *inp, ftxTensor *out);

#ifdef __cplusplus
}
#endif

#endif /* FORTX_H_ */
