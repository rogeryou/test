// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MATMUL_H_
#define MATMUL_H_

void matmul_i8i8f32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, float* C);
void matmul_bt_i8i8f32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, float* C);
void matmul_i8i8i32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, int32_t* C);
void matmul_bt_i8i8i32(size_t M, size_t K, size_t N, const int8_t* A, const int8_t* B, int32_t* C);
void matmul_i8f32f32(size_t M, size_t K, size_t N, const int8_t* A, const float* B, float* C);
void matmul_bt_i8f32f32(size_t M, size_t K, size_t N, const int8_t* A, const float* B, float* C);
void matmul_f16f32f32(size_t M, size_t K, size_t N, const float16* A, const float* B, float* C);
void matmul_bt_f16f32f32(size_t M, size_t K, size_t N, const float16* A, const float* B, float* C);
void matmul_f32f16f32(size_t M, size_t K, size_t N, const float* A, const float16* B, float* C);
void matmul_bt_f32f16f32(size_t M, size_t K, size_t N, const float* A, const float16* B, float* C);
void matmul_f32f32f32(size_t M, size_t K, size_t N, const float* A, const float* B, float* C);
void matmul_bt_f32f32f32(size_t M, size_t K, size_t N, const float* A, const float* B, float* C);

// quantize matmul
void matmul_bt_q8q8f32(size_t M, size_t K, size_t N, const int8_t* A_q, const float* A_s, const int8_t* B_q, const float* B_s, float* C, int q_bsize);

#endif /* MATMUL_H_ */