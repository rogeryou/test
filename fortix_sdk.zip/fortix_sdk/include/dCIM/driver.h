/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*!
 * \file dCIM/driver.h
 * \brief Driver interface that is used by runtime.
 *
 * Driver's implementation is device specific.
 */

#ifndef DCIM_DRIVER_H_
#define DCIM_DRIVER_H_

#include <stdint.h>
#include <stdlib.h>


#ifdef __cplusplus
extern "C" {
#endif

/*! \brief Memory management constants for cached memory */
#define FTX_CACHED 1
/*! \brief Memory management constants for non-cached memory */
#define FTX_NOT_CACHED 0

/*! \brief Physically contiguous buffer size limit */
#ifndef FTX_MAX_XFER
#define FTX_MAX_XFER (1<<25)
#endif

/*! PAGE SIZE */
#define FTX_PAGE_BITS 12
#define FTX_PAGE_BYTES (1 << FTX_PAGE_BITS)
#define FTX_MAX_PAGES 256 * 4096

/*! \brief Device resource context  */
typedef void * ftxDeviceHandle;

/*! \brief physical address */
typedef uint64_t ftx_phy_addr_t;


/*!
 * \brief Allocate a device resource handle
 * \return The device handle.
 */
ftxDeviceHandle ftxDeviceAlloc();

/*!
 * \brief Free a device handle
 * \param handle The device handle to be freed.
 */
void ftxDeviceFree(ftxDeviceHandle handle);

/*!
 * \brief Launch the instructions block until done.
 * \param device The device handle.
 * \param insn_phy_addr The physical address of instruction stream.
 * \param insn_count Instruction count.
 * \param wait_cycles The maximum of cycles to wait
 *
 * \return 0 if running is successful, 1 if timeout.
 */
int ftxDeviceRun(ftxDeviceHandle device,
                 ftx_phy_addr_t insn_phy_addr,
                 uint32_t insn_count,
                 uint32_t wait_cycles);

/*!
 * \brief Allocates physically contiguous region in memory readable/writeable by FPGA.
 * \param size Size of the region in Bytes.
 * \param cached Region can be set to not cached (write-back) if set to 0.
 * \return A pointer to the allocated region.
 */
void* ftxMemAlloc(size_t size, int cached);

/*!
 * \brief Frees a physically contiguous region in memory readable/writeable by FPGA.
 * \param buf Buffer to free.
 */
void ftxMemFree(void* buf);

/*!
 * \brief Returns a physical address to the region of memory allocated with ftxMemAlloc.
 * \param buf Pointer to memory region allocated with ftxMemAlloc.
 * \return The physical address of the memory region.
 */
ftx_phy_addr_t ftxMemGetPhyAddr(void* buf);

/*!
 * \brief Performs a copy operation from host memory to buffer allocated with ftxMemAlloc.
 * \param dst The desination buffer in FPGA-accessible memory. Has to be allocated with ftxMemAlloc.
 * \param src The source buffer in host memory.
 * \param size Size of the region in Bytes.
 */
void ftxMemCopyFromHost(void* dst, const void* src, size_t size);

/*!
 * \brief Performs a copy operation from buffer allocated with ftxMemAlloc to host memory.
 * \param dst The destination buffer in host memory.
 * \param src The source buffer in FPGA-accessible memory. Has to be allocated with ftxMemAlloc.
 * \param size Size of the region in Bytes.
 */
void ftxMemCopyToHost(void* dst, const void* src, size_t size);

/*!
 * \brief Flushes the region of memory out of the CPU cache to DRAM.
 * \param vir_addr Pointer to memory region allocated with ftxMemAlloc to be flushed.
 *                 This need to be the virtual address.
 * \param phy_addr Pointer to memory region allocated with ftxMemAlloc to be flushed.
 *                 This need to be the physical address.
 * \param size Size of the region to flush in Bytes.
 */
void ftxFlushCache(void* vir_addr, ftx_phy_addr_t phy_addr, int size);

/*!
 * \brief Invalidates the region of memory that is cached.
 * \param vir_addr Pointer to memory region allocated with ftxMemAlloc to be invalidated.
 *                 This need to be the virtual address.
 * \param phy_addr Pointer to memory region allocated with ftxMemAlloc to be invalidated.
 *                 This need to be the physical address.
 * \param size Size of the region to invalidate in Bytes.
 */
void ftxInvalidateCache(void* vir_addr, ftx_phy_addr_t phy_addr, int size);

#ifdef __cplusplus
}
#endif
#endif  // DCIM_DRIVER_H_
