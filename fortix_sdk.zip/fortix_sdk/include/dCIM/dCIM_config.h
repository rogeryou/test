#ifndef DCIM_CONFIG_H_
#define DCIM_CONFIG_H_

#define TARGET "sim"
#define DCIM_LOG_INP_WIDTH 3
#define DCIM_LOG_WGT_WIDTH 3
#define DCIM_LOG_ACC_WIDTH 5
#define DCIM_LOG_BATCH 0
#define DCIM_LOG_BLOCK_IN 4
#define DCIM_LOG_BLOCK_OUT 4
#define DCIM_LOG_UOP_BUFF_SIZE 15
#define DCIM_LOG_INP_BUFF_SIZE 15
#define DCIM_LOG_WGT_BUFF_SIZE 18
#define DCIM_LOG_ACC_BUFF_SIZE 17

// define in dCIM-hw/config/pk-config
#define DCIM_LOG_OUT_WIDTH DCIM_LOG_INP_WIDTH
#define DCIM_LOG_OUT_BUFF_SIZE (DCIM_LOG_ACC_BUFF_SIZE+DCIM_LOG_OUT_WIDTH-DCIM_LOG_ACC_WIDTH)

/*! \brief Enable coherent access of data buffers between dCIM and ftx CPU */
#define DCIM_COHERENT_ACCESSES true


#endif  // DCIM_CONFIG_H_