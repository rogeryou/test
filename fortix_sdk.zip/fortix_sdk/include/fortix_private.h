// SPDX-License-Identifier: Apache-2.0
/*
 * Copyright 2025 Macronix International Co. LTD.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef FORTIX_PRIVATE_H_
#define FORTIX_PRIVATE_H_

#include <iostream>
#include <string>

using namespace std;

#define LOG_ERROR std::cout
#define LOG_WARN std::cout
#define LOG_INFO std::cout
#define LOG_ENDL std::endl

// -----------------------------------------------------------------------------
// Misc Macros
// -----------------------------------------------------------------------------

#define CEIL(a, b) (uint64_t)((a + b - 1) / b) // positive numbers only
#define MIN(a, b) ((a > b) ? b : a)
#define MAX(a, b) ((a < b) ? b : a)
#define BIT_SIZEOF(a) (sizeof(a) * 8)

// padded = next multiple of AIU_2BYTE_CELLS_PER_STICK
#define PADDED(x)                                                              \
    ((uint32_t)CEIL(x, 64) * 64)

short GetDataLayoutDims(ftxDataLayout layout);
const string& GetDataLayoutStr(ftxDataLayout layout);
uint32_t GetDataTypeBits(ftxDataType type);
const string& GetDataTypeStr(ftxDataType type);

int8_t Int32ToInt8(int32_t in_data);
int8_t FP32ToInt8(float in_data);
float Int8ToFP32(int8_t in_data);
int32_t Int8ToInt32(int8_t in_data);
float FP16ToFP32(float16 x);
float16 FP32ToFP16(float x);

size_t ComputeSize(const std::vector<int>& dim);
std::vector<int> ComputeStrides(const std::vector<int> &shape,
                                size_t elem_bits);
std::vector<int> OffsetToIndex(int offset, const std::vector<int> &shape);
int IndexToOffset(const std::vector<int> &index,
                  const std::vector<int> &strides, size_t elem_bits);

// for broadcast operators
ftxBroadcast BroadcastType(const vector<int> A, const vector<int> B);
vector<int> BroadcastOutShape(const vector<int> A, const vector<int> B);
vector<int> BroadcastStride(ftxTensor *self, vector<int> stride,
                            ftxTensor *bcast_result);

#endif /* DCIM_PRIVATE_H_ */
